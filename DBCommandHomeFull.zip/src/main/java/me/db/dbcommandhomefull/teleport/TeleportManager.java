
package me.db.dbcommandhomefull.teleport;

import me.db.dbcommandhomefull.DBCommandHomeFull;
import me.db.dbcommandhomefull.util.Msg;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TeleportManager implements Listener {

    private final DBCommandHomeFull plugin;
    private final Map<UUID, Location> pending = new HashMap<>();

    public TeleportManager(DBCommandHomeFull plugin) {
        this.plugin = plugin;
    }

    public void start(Player player, Location target) {
        int delay = plugin.getConfig().getInt("teleport.delay");
        Msg.send(player, "teleport-start");
        pending.put(player.getUniqueId(), player.getLocation());

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!pending.containsKey(player.getUniqueId())) return;

                pending.remove(player.getUniqueId());
                player.teleport(target);
                player.playSound(player.getLocation(),
                        Sound.valueOf(plugin.getConfig().getString("sounds.teleport")),
                        1f, 1f);

                player.sendTitle(
                        Msg.color(plugin.getConfig().getString("titles.teleport.title")),
                        Msg.color(plugin.getConfig().getString("titles.teleport.subtitle")),
                        plugin.getConfig().getInt("titles.teleport.fade-in"),
                        plugin.getConfig().getInt("titles.teleport.stay"),
                        plugin.getConfig().getInt("titles.teleport.fade-out")
                );
            }
        }.runTaskLater(plugin, delay * 20L);
    }

    @EventHandler
    public void move(PlayerMoveEvent e) {
        if (!plugin.getConfig().getBoolean("teleport.cancel-on-move")) return;

        UUID u = e.getPlayer().getUniqueId();
        if (!pending.containsKey(u)) return;

        if (e.getFrom().distanceSquared(e.getTo()) > 0) {
            pending.remove(u);
            Msg.send(e.getPlayer(), "teleport-cancelled");
        }
    }
}
