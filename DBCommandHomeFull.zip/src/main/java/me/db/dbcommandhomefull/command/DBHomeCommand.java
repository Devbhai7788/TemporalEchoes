
package me.db.dbcommandhomefull.command;

import me.db.dbcommandhomefull.DBCommandHomeFull;
import me.db.dbcommandhomefull.util.Msg;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class DBHomeCommand implements CommandExecutor {

    private final DBCommandHomeFull plugin;

    public DBHomeCommand(DBCommandHomeFull plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Msg.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        if (!p.hasPermission("dbcommandhomefull.admin")) {
            Msg.send(p, "no-permission");
            return true;
        }

        if (args.length != 1) return true;

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        Location loc = plugin.homes().get(target.getUniqueId());
        if (loc == null) {
            Msg.send(p, "no-home");
            return true;
        }

        plugin.teleport().start(p, loc);
        return true;
    }
}
