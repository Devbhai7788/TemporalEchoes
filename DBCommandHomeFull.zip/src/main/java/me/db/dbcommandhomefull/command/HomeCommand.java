
package me.db.dbcommandhomefull.command;

import me.db.dbcommandhomefull.DBCommandHomeFull;
import me.db.dbcommandhomefull.util.Msg;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.Location;

public class HomeCommand implements CommandExecutor {

    private final DBCommandHomeFull plugin;

    public HomeCommand(DBCommandHomeFull plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Msg.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        Location loc = plugin.homes().get(p.getUniqueId());
        if (loc == null) {
            Msg.send(p, "no-home");
            return true;
        }

        plugin.teleport().start(p, loc);
        return true;
    }
}
