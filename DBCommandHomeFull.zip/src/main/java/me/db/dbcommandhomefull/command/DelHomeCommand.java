
package me.db.dbcommandhomefull.command;

import me.db.dbcommandhomefull.DBCommandHomeFull;
import me.db.dbcommandhomefull.util.Msg;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class DelHomeCommand implements CommandExecutor {

    private final DBCommandHomeFull plugin;

    public DelHomeCommand(DBCommandHomeFull plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Msg.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        plugin.homes().delete(p.getUniqueId());
        Msg.send(p, "delete");
        return true;
    }
}
