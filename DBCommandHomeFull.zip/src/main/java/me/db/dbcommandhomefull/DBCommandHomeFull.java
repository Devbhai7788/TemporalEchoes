
package me.db.dbcommandhomefull;

import me.db.dbcommandhomefull.command.*;
import me.db.dbcommandhomefull.home.HomeManager;
import me.db.dbcommandhomefull.teleport.TeleportManager;
import me.db.dbcommandhomefull.util.Msg;
import org.bukkit.plugin.java.JavaPlugin;

public class DBCommandHomeFull extends JavaPlugin {

    private static DBCommandHomeFull instance;
    private HomeManager homes;
    private TeleportManager teleport;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        Msg.init(this);
        homes = new HomeManager(this);
        teleport = new TeleportManager(this);

        getCommand("sethome").setExecutor(new SetHomeCommand(this));
        getCommand("home").setExecutor(new HomeCommand(this));
        getCommand("delhome").setExecutor(new DelHomeCommand(this));
        getCommand("dbhome").setExecutor(new DBHomeCommand(this));

        getServer().getPluginManager().registerEvents(teleport, this);
    }

    public static DBCommandHomeFull get() {
        return instance;
    }

    public HomeManager homes() {
        return homes;
    }

    public TeleportManager teleport() {
        return teleport;
    }
}
