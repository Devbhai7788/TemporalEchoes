
package me.db.dbcommandhomefull.util;

import me.db.dbcommandhomefull.DBCommandHomeFull;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class Msg {

    private static DBCommandHomeFull plugin;

    public static void init(DBCommandHomeFull p) {
        plugin = p;
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public static void send(Player p, String key) {
        p.sendMessage(color(
                plugin.getConfig().getString("prefix")
                        + plugin.getConfig().getString("messages." + key)
        ));
    }
}
