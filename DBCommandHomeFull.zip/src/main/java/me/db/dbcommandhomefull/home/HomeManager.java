
package me.db.dbcommandhomefull.home;

import org.bukkit.*;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class HomeManager {

    private final File folder;

    public HomeManager(org.bukkit.plugin.Plugin plugin) {
        folder = new File(plugin.getDataFolder(), "homes");
        if (!folder.exists()) folder.mkdirs();
    }

    private File file(UUID uuid) {
        return new File(folder, uuid + ".yml");
    }

    public void set(UUID uuid, Location loc) {
        File f = file(uuid);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);

        y.set("world", loc.getWorld().getName());
        y.set("x", loc.getX());
        y.set("y", loc.getY());
        y.set("z", loc.getZ());
        y.set("yaw", loc.getYaw());
        y.set("pitch", loc.getPitch());

        try { y.save(f); } catch (IOException ignored) {}
    }

    public Location get(UUID uuid) {
        File f = file(uuid);
        if (!f.exists()) return null;

        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        World w = Bukkit.getWorld(y.getString("world"));
        if (w == null) return null;

        return new Location(
                w,
                y.getDouble("x"),
                y.getDouble("y"),
                y.getDouble("z"),
                (float) y.getDouble("yaw"),
                (float) y.getDouble("pitch")
        );
    }

    public void delete(UUID uuid) {
        File f = file(uuid);
        if (f.exists()) f.delete();
    }
}
