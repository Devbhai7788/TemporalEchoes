
package me.db.dbcommandhome;

import me.db.dbcommandhome.command.*;
import me.db.dbcommandhome.home.HomeManager;
import me.db.dbcommandhome.teleport.TeleportManager;
import me.db.dbcommandhome.util.Msg;
import org.bukkit.plugin.java.JavaPlugin;

/*
 Main plugin class
 Handles startup, command registration and managers
*/
public class DBCommandHome extends JavaPlugin {

    private static DBCommandHome instance;
    private HomeManager homeManager;
    private TeleportManager teleportManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        Msg.init(this);
        homeManager = new HomeManager(this);
        teleportManager = new TeleportManager(this);

        getCommand("sethome").setExecutor(new SetHomeCommand(this));
        getCommand("home").setExecutor(new HomeCommand(this));
        getCommand("delhome").setExecutor(new DelHomeCommand(this));
        getCommand("dbhome").setExecutor(new DBHomeCommand(this));

        getServer().getPluginManager().registerEvents(teleportManager, this);
    }

    public static DBCommandHome get() {
        return instance;
    }

    public HomeManager homes() {
        return homeManager;
    }

    public TeleportManager teleport() {
        return teleportManager;
    }
}
