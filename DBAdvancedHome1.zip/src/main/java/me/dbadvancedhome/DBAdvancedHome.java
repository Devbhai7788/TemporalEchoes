package me.dbadvancedhome;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DBAdvancedHome extends JavaPlugin implements Listener {

    private File homesFile;
    private FileConfiguration homes;
    private final Map<UUID, BukkitTask> teleportTasks = new HashMap<>();
    private final Map<UUID, Location> teleportStart = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        loadHomes();
    }

    private String msg(String path) {
        String prefix = ChatColor.translateAlternateColorCodes('&', getConfig().getString("prefix", ""));
        String m = ChatColor.translateAlternateColorCodes('&', getConfig().getString("messages." + path, path));
        return prefix + m;
    }

    private void loadHomes() {
        homesFile = new File(getDataFolder(), "homes.yml");
        if (!homesFile.exists()) {
            try {
                homesFile.getParentFile().mkdirs();
                homesFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        homes = YamlConfiguration.loadConfiguration(homesFile);
    }

    private void saveHomes() {
        try {
            homes.save(homesFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int getLimit(Player p) {
        if (p.hasPermission("dbadvancedhome.homes.25")) return 25;
        if (p.hasPermission("dbadvancedhome.homes.10")) return 10;
        if (p.hasPermission("dbadvancedhome.homes.5")) return 5;
        return 1;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(msg("only-player"));
            return true;
        }

        if (command.getName().equalsIgnoreCase("home")) {
            Location loc = homes.getLocation(p.getUniqueId() + ".home1");
            if (loc == null) {
                p.sendMessage(msg("home-not-set"));
                return true;
            }
            startTeleport(p, loc);
        }

        if (command.getName().equalsIgnoreCase("homes")) {
            openGUI(p, p.getUniqueId());
        }

        if (command.getName().equalsIgnoreCase("hometp")) {
            if (!p.hasPermission("dbadvancedhome.hometp")) {
                p.sendMessage(msg("no-permission"));
                return true;
            }
            if (args.length != 1) {
                p.sendMessage(msg("usage-hometp"));
                return true;
            }
            OfflinePlayer off = Bukkit.getOfflinePlayer(args[0]);
            if (off.getUniqueId() == null) {
                p.sendMessage(msg("player-not-found"));
                return true;
            }
            openGUI(p, off.getUniqueId());
        }
        return true;
    }

    private void startTeleport(Player p, Location loc) {
        int delay = getConfig().getInt("teleport.delay", 5);
        p.sendMessage(msg("teleport-start"));
        teleportStart.put(p.getUniqueId(), p.getLocation());

        BukkitTask task = Bukkit.getScheduler().runTaskLater(this, () -> {
            p.teleport(loc);
            p.sendMessage(msg("home-teleport"));
            teleportTasks.remove(p.getUniqueId());
            teleportStart.remove(p.getUniqueId());
        }, delay * 20L);

        teleportTasks.put(p.getUniqueId(), task);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (!teleportTasks.containsKey(p.getUniqueId())) return;

        if (getConfig().getBoolean("teleport.cancel-on-move", true)) {
            if (e.getFrom().getBlockX() != e.getTo().getBlockX()
                    || e.getFrom().getBlockY() != e.getTo().getBlockY()
                    || e.getFrom().getBlockZ() != e.getTo().getBlockZ()) {

                teleportTasks.get(p.getUniqueId()).cancel();
                teleportTasks.remove(p.getUniqueId());
                teleportStart.remove(p.getUniqueId());
                p.sendMessage(msg("teleport-cancelled"));
            }
        }
    }

    private void openGUI(Player viewer, UUID owner) {
        Inventory inv = Bukkit.createInventory(null, 27, "Homes");
        int limit = owner.equals(viewer.getUniqueId()) ? getLimit(viewer) : 25;

        for (int i = 1; i <= limit; i++) {
            ItemStack bed = new ItemStack(Material.RED_BED);
            ItemMeta meta = bed.getItemMeta();
            meta.setDisplayName(ChatColor.GREEN + "Home " + i);

            List<String> lore = new ArrayList<>();
            if (homes.contains(owner + ".home" + i)) {
                lore.add(ChatColor.BLUE + "Tap to Unset");
            } else {
                lore.add(ChatColor.GREEN + "Tap to Set Home");
            }
            meta.setLore(lore);
            bed.setItemMeta(meta);
            inv.setItem(i - 1, bed);
        }
        viewer.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("Homes")) return;
        e.setCancelled(true);

        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack item = e.getCurrentItem();
        if (item == null || !item.hasItemMeta()) return;

        String name = ChatColor.stripColor(item.getItemMeta().getDisplayName());
        int index = Integer.parseInt(name.replace("Home ", ""));

        String path = p.getUniqueId() + ".home" + index;

        if (homes.contains(path)) {
            homes.set(path, null);
            p.sendMessage(msg("home-unset"));
        } else {
            homes.set(path, p.getLocation());
            p.sendMessage(msg("home-set"));
        }
        saveHomes();
        openGUI(p, p.getUniqueId());
    }
}
