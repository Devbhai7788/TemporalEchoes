package com.db.advancedhome.inventory.impl;

import com.cryptomorin.xseries.XMaterial;
import com.cryptomorin.xseries.XSound;
import com.db.advancedhome.DBAdvancedHome;
import com.db.advancedhome.inventory.InventoryButton;
import com.db.advancedhome.inventory.InventoryGUI;
import com.db.advancedhome.model.Home;
import com.db.advancedhome.model.PlayerHomeData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;

public class HomesGUI extends InventoryGUI {
    private final DBAdvancedHome plugin;
    private final Player player;
    
    public HomesGUI(DBAdvancedHome plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
    }
    
    @Override
    protected Inventory createInventory() {
        String title = ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("gui.title", "&8Homes Manager"));
        return Bukkit.createInventory(null, 54, title);
    }
    
    @Override
    public void decorate(Player player) {
        PlayerHomeData data = plugin.getHomeManager().getPlayerData(player.getUniqueId());
        
        if (data.getHomes().isEmpty()) {
            addButton(22, new InventoryButton()
                .creator(p -> createNoHomesItem())
                .consumer(event -> {})
            );
        } else {
            int slot = 10;
            for (Home home : data.getHomes().values()) {
                if (slot >= 44) break;
                
                if (slot % 9 == 8) slot += 2;
                
                addButton(slot, new InventoryButton()
                    .creator(p -> createHomeItem(home))
                    .consumer(event -> {
                        if (event.getClick() == ClickType.LEFT) {
                            handleHomeTeleport(home);
                        } else if (event.getClick() == ClickType.RIGHT) {
                            handleHomeDelete(home);
                        }
                    })
                );
                slot++;
            }
        }
        
        addButton(49, new InventoryButton()
            .creator(p -> createCloseItem())
            .consumer(event -> {
                player.closeInventory();
                XSound.matchXSound("UI_BUTTON_CLICK").ifPresent(s -> s.play(player));
            })
        );
        
        super.decorate(player);
    }
    
    private ItemStack createHomeItem(Home home) {
        ItemStack item = XMaterial.matchXMaterial(home.getIcon())
            .map(XMaterial::parseItem)
            .orElse(null);
        
        if (item == null) {
            item = XMaterial.RED_BED.parseItem();
        }
        
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&e&l" + home.getName()));
        
        List<String> lore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("gui.home-item.lore")) {
            lore.add(ChatColor.translateAlternateColorCodes('&', line
                .replace("{world}", home.getWorld())
                .replace("{x}", String.format("%.1f", home.getX()))
                .replace("{y}", String.format("%.1f", home.getY()))
                .replace("{z}", String.format("%.1f", home.getZ()))
            ));
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        
        return item;
    }
    
    private ItemStack createNoHomesItem() {
        String materialName = plugin.getConfig().getString("gui.no-homes-item.material", "BARRIER");
        ItemStack item = XMaterial.matchXMaterial(materialName)
            .map(XMaterial::parseItem)
            .orElse(null);
        
        if (item == null) {
            item = XMaterial.BARRIER.parseItem();
        }
        
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("gui.no-homes-item.name", "&cNo Homes")));
        
        List<String> lore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("gui.no-homes-item.lore")) {
            lore.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        
        return item;
    }
    
    private ItemStack createCloseItem() {
        String materialName = plugin.getConfig().getString("gui.close-item.material", "BARRIER");
        ItemStack item = XMaterial.matchXMaterial(materialName)
            .map(XMaterial::parseItem)
            .orElse(null);
        
        if (item == null) {
            item = XMaterial.BARRIER.parseItem();
        }
        
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("gui.close-item.name", "&cClose")));
        item.setItemMeta(meta);
        
        return item;
    }
    
    private void handleHomeTeleport(Home home) {
        player.closeInventory();
        
        Location homeLocation = home.getLocation();
        if (homeLocation == null) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + 
                "&cHome world no longer exists!"));
            PlayerHomeData data = plugin.getHomeManager().getPlayerData(player.getUniqueId());
            data.removeHome(home.getName());
            return;
        }
        
        if (plugin.getHomeManager().isOnCooldown(player)) {
            long remaining = plugin.getHomeManager().getRemainingCooldown(player);
            String message = plugin.getConfig().getString("messages.cooldown-active", "")
                .replace("{time}", String.valueOf(remaining));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            XSound.matchXSound("ENTITY_VILLAGER_NO").ifPresent(s -> s.play(player));
            return;
        }
        
        int warmupTime = plugin.getConfig().getInt("warmup-time", 5);
        
        if (plugin.getConfig().getBoolean("enable-warmup", true) && warmupTime > 0 
            && !player.hasPermission("dbadvancedhome.bypass.warmup")) {
            String message = plugin.getConfig().getString("messages.teleporting", "")
                .replace("{name}", home.getName())
                .replace("{time}", String.valueOf(warmupTime));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                player.teleport(homeLocation);
                plugin.getHomeManager().setLastTeleport(player);
                String successMsg = plugin.getConfig().getString("messages.teleport-success", "")
                    .replace("{name}", home.getName());
                player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.prefix", "") + successMsg));
                XSound.matchXSound("ENTITY_ENDERMAN_TELEPORT").ifPresent(s -> s.play(player));
            }, warmupTime * 20L);
        } else {
            player.teleport(homeLocation);
            plugin.getHomeManager().setLastTeleport(player);
            String message = plugin.getConfig().getString("messages.teleport-success", "")
                .replace("{name}", home.getName());
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            XSound.matchXSound("ENTITY_ENDERMAN_TELEPORT").ifPresent(s -> s.play(player));
        }
    }
    
    private void handleHomeDelete(Home home) {
        PlayerHomeData data = plugin.getHomeManager().getPlayerData(player.getUniqueId());
        data.removeHome(home.getName());
        
        String message = plugin.getConfig().getString("messages.home-deleted", "")
            .replace("{name}", home.getName());
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.prefix", "") + message));
        
        XSound.matchXSound("ENTITY_ITEM_BREAK").ifPresent(s -> s.play(player));
        
        player.closeInventory();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getGuiManager().openGUI(new HomesGUI(plugin, player), player);
        }, 1L);
    }
}