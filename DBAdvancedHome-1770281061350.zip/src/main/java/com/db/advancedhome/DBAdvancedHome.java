package com.db.advancedhome;

import com.db.advancedhome.command.*;
import com.db.advancedhome.inventory.gui.GUIListener;
import com.db.advancedhome.inventory.gui.GUIManager;
import com.db.advancedhome.manager.HomeManager;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

@Getter
public class DBAdvancedHome extends JavaPlugin {
    private GUIManager guiManager;
    private HomeManager homeManager;
    
    @Override
    public void onEnable() {
        saveDefaultConfig();
        
        this.guiManager = new GUIManager();
        this.homeManager = new HomeManager(this);
        
        registerCommands();
        registerListeners();
        
        homeManager.loadHomes();
        
        getLogger().info("DBAdvancedHome has been enabled!");
    }
    
    @Override
    public void onDisable() {
        if (homeManager != null) {
            homeManager.saveHomes();
        }
        getLogger().info("DBAdvancedHome has been disabled!");
    }
    
    private void registerCommands() {
        getCommand("sethome").setExecutor(new SetHomeCommand(this));
        getCommand("delhome").setExecutor(new DelHomeCommand(this));
        getCommand("home").setExecutor(new HomeCommand(this));
        getCommand("homes").setExecutor(new HomesCommand(this));
        getCommand("homeadmin").setExecutor(new HomeAdminCommand(this));
    }
    
    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new GUIListener(guiManager), this);
    }
    
    public void reloadPlugin() {
        reloadConfig();
        homeManager.loadHomes();
    }
}