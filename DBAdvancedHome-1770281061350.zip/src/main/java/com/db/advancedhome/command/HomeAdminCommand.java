package com.db.advancedhome.command;

import com.db.advancedhome.DBAdvancedHome;
import com.db.advancedhome.model.Home;
import com.db.advancedhome.model.PlayerHomeData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import java.util.Map;

public class HomeAdminCommand implements CommandExecutor {
    private final DBAdvancedHome plugin;
    
    public HomeAdminCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("dbadvancedhome.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
            return true;
        }
        
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "reload":
                plugin.reloadPlugin();
                String message = plugin.getConfig().getString("messages.reload-success", "");
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.prefix", "") + message));
                break;
                
            case "clear":
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Usage: /homeadmin clear <player>");
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                if (!target.hasPlayedBefore() && !target.isOnline()) {
                    String notFoundMsg = plugin.getConfig().getString("messages.player-not-found", "");
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                        plugin.getConfig().getString("messages.prefix", "") + notFoundMsg));
                    return true;
                }
                plugin.getHomeManager().clearPlayerHomes(target.getUniqueId());
                String clearedMsg = plugin.getConfig().getString("messages.homes-cleared", "")
                    .replace("{player}", target.getName());
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.prefix", "") + clearedMsg));
                break;
                
            case "list":
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Usage: /homeadmin list <player>");
                    return true;
                }
                OfflinePlayer listTarget = Bukkit.getOfflinePlayer(args[1]);
                PlayerHomeData data = plugin.getHomeManager().getPlayerData(listTarget.getUniqueId());
                
                sender.sendMessage(ChatColor.GOLD + "=== Homes for " + listTarget.getName() + " ===");
                if (data.getHomes().isEmpty()) {
                    sender.sendMessage(ChatColor.GRAY + "No homes set.");
                } else {
                    for (Map.Entry<String, Home> entry : data.getHomes().entrySet()) {
                        Home home = entry.getValue();
                        sender.sendMessage(ChatColor.YELLOW + home.getName() + ChatColor.GRAY + " - " +
                            home.getWorld() + " (" +
                            String.format("%.1f", home.getX()) + ", " +
                            String.format("%.1f", home.getY()) + ", " +
                            String.format("%.1f", home.getZ()) + ")");
                    }
                }
                break;
                
            default:
                sendHelp(sender);
                break;
        }
        
        return true;
    }
    
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== Home Admin Commands ===");
        sender.sendMessage(ChatColor.YELLOW + "/homeadmin reload" + ChatColor.GRAY + " - Reload configuration");
        sender.sendMessage(ChatColor.YELLOW + "/homeadmin clear <player>" + ChatColor.GRAY + " - Clear player's homes");
        sender.sendMessage(ChatColor.YELLOW + "/homeadmin list <player>" + ChatColor.GRAY + " - List player's homes");
    }
}