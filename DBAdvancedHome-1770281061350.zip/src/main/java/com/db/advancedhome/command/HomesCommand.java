package com.db.advancedhome.command;

import com.db.advancedhome.DBAdvancedHome;
import com.db.advancedhome.inventory.impl.HomesGUI;
import com.db.advancedhome.model.PlayerHomeData;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomesCommand implements CommandExecutor {
    private final DBAdvancedHome plugin;
    
    public HomesCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("dbadvancedhome.use")) {
            player.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
            return true;
        }
        
        PlayerHomeData data = plugin.getHomeManager().getPlayerData(player.getUniqueId());
        
        if (data.getHomes().isEmpty()) {
            String message = plugin.getConfig().getString("messages.no-homes", "");
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            return true;
        }
        
        plugin.getGuiManager().openGUI(new HomesGUI(plugin, player), player);
        
        return true;
    }
}