package com.db.advancedhome.command;

import com.cryptomorin.xseries.XSound;
import com.db.advancedhome.DBAdvancedHome;
import com.db.advancedhome.model.Home;
import com.db.advancedhome.model.PlayerHomeData;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetHomeCommand implements CommandExecutor {
    private final DBAdvancedHome plugin;
    
    public SetHomeCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("dbadvancedhome.use")) {
            player.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
            return true;
        }
        
        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Usage: /sethome <name>");
            return true;
        }
        
        String homeName = args[0];
        
        if (!homeName.matches("^[a-zA-Z0-9_]+$")) {
            String message = plugin.getConfig().getString("messages.invalid-name", "");
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            return true;
        }
        
        PlayerHomeData data = plugin.getHomeManager().getPlayerData(player.getUniqueId());
        
        if (data.hasHome(homeName)) {
            String message = plugin.getConfig().getString("messages.home-already-exists", "")
                .replace("{name}", homeName);
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            return true;
        }
        
        if (!plugin.getHomeManager().canSetHome(player)) {
            int max = plugin.getHomeManager().getMaxHomes(player);
            String message = plugin.getConfig().getString("messages.max-homes-reached", "")
                .replace("{max}", String.valueOf(max));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            XSound.matchXSound("ENTITY_VILLAGER_NO").ifPresent(s -> s.play(player));
            return true;
        }
        
        String defaultIcon = plugin.getConfig().getString("default-home-icon", "RED_BED");
        Home home = Home.fromLocation(homeName, player.getLocation(), defaultIcon);
        data.addHome(home);
        
        String message = plugin.getConfig().getString("messages.home-set", "")
            .replace("{name}", homeName);
        player.sendMessage(ChatColor.translateAlternateColorCodes('&',
            plugin.getConfig().getString("messages.prefix", "") + message));
        
        XSound.matchXSound("BLOCK_NOTE_BLOCK_PLING").ifPresent(s -> s.play(player));
        
        return true;
    }
}