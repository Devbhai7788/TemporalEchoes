package com.db.advancedhome.command;

import com.cryptomorin.xseries.XSound;
import com.db.advancedhome.DBAdvancedHome;
import com.db.advancedhome.inventory.impl.HomesGUI;
import com.db.advancedhome.model.Home;
import com.db.advancedhome.model.PlayerHomeData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomeCommand implements CommandExecutor {
    private final DBAdvancedHome plugin;
    
    public HomeCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("dbadvancedhome.use")) {
            player.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
            return true;
        }
        
        PlayerHomeData data = plugin.getHomeManager().getPlayerData(player.getUniqueId());
        
        if (data.getHomes().isEmpty()) {
            String message = plugin.getConfig().getString("messages.no-homes", "");
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            return true;
        }
        
        if (args.length == 0) {
            plugin.getGuiManager().openGUI(new HomesGUI(plugin, player), player);
            return true;
        }
        
        String homeName = args[0];
        Home home = data.getHome(homeName);
        
        if (home == null) {
            String message = plugin.getConfig().getString("messages.home-not-found", "")
                .replace("{name}", homeName);
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            return true;
        }
        
        Location homeLocation = home.getLocation();
        if (homeLocation == null) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + 
                "&cHome world no longer exists!"));
            data.removeHome(homeName);
            return true;
        }
        
        if (plugin.getHomeManager().isOnCooldown(player)) {
            long remaining = plugin.getHomeManager().getRemainingCooldown(player);
            String message = plugin.getConfig().getString("messages.cooldown-active", "")
                .replace("{time}", String.valueOf(remaining));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            XSound.matchXSound("ENTITY_VILLAGER_NO").ifPresent(s -> s.play(player));
            return true;
        }
        
        int warmupTime = plugin.getConfig().getInt("warmup-time", 5);
        
        if (plugin.getConfig().getBoolean("enable-warmup", true) && warmupTime > 0
            && !player.hasPermission("dbadvancedhome.bypass.warmup")) {
            String message = plugin.getConfig().getString("messages.teleporting", "")
                .replace("{name}", home.getName())
                .replace("{time}", String.valueOf(warmupTime));
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                player.teleport(homeLocation);
                plugin.getHomeManager().setLastTeleport(player);
                String successMsg = plugin.getConfig().getString("messages.teleport-success", "")
                    .replace("{name}", home.getName());
                player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getConfig().getString("messages.prefix", "") + successMsg));
                XSound.matchXSound("ENTITY_ENDERMAN_TELEPORT").ifPresent(s -> s.play(player));
            }, warmupTime * 20L);
        } else {
            player.teleport(homeLocation);
            plugin.getHomeManager().setLastTeleport(player);
            String message = plugin.getConfig().getString("messages.teleport-success", "")
                .replace("{name}", home.getName());
            player.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("messages.prefix", "") + message));
            XSound.matchXSound("ENTITY_ENDERMAN_TELEPORT").ifPresent(s -> s.play(player));
        }
        
        return true;
    }
}