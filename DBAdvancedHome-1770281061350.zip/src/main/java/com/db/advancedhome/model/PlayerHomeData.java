package com.db.advancedhome.model;

import lombok.Data;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Data
public class PlayerHomeData {
    private UUID playerId;
    private Map<String, Home> homes;
    private long lastTeleport;
    
    public PlayerHomeData(UUID playerId) {
        this.playerId = playerId;
        this.homes = new HashMap<>();
        this.lastTeleport = 0;
    }
    
    public void addHome(Home home) {
        homes.put(home.getName().toLowerCase(), home);
    }
    
    public void removeHome(String name) {
        homes.remove(name.toLowerCase());
    }
    
    public Home getHome(String name) {
        return homes.get(name.toLowerCase());
    }
    
    public boolean hasHome(String name) {
        return homes.containsKey(name.toLowerCase());
    }
    
    public int getHomeCount() {
        return homes.size();
    }
}