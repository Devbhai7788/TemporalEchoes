package com.db.advancedhome.manager;

import com.db.advancedhome.DBAdvancedHome;
import com.db.advancedhome.model.Home;
import com.db.advancedhome.model.PlayerHomeData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class HomeManager {
    private final DBAdvancedHome plugin;
    private final Map<UUID, PlayerHomeData> playerData;
    private File homesFile;
    private FileConfiguration homesConfig;
    
    public HomeManager(DBAdvancedHome plugin) {
        this.plugin = plugin;
        this.playerData = new HashMap<>();
        setupHomesFile();
    }
    
    private void setupHomesFile() {
        homesFile = new File(plugin.getDataFolder(), "homes.yml");
        if (!homesFile.exists()) {
            try {
                homesFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        homesConfig = YamlConfiguration.loadConfiguration(homesFile);
    }
    
    public PlayerHomeData getPlayerData(UUID playerId) {
        return playerData.computeIfAbsent(playerId, PlayerHomeData::new);
    }
    
    public int getMaxHomes(Player player) {
        if (player.hasPermission("dbadvancedhome.unlimited")) {
            return Integer.MAX_VALUE;
        }
        if (player.hasPermission("dbadvancedhome.homes.premium")) {
            return plugin.getConfig().getInt("max-homes.premium", 10);
        }
        if (player.hasPermission("dbadvancedhome.homes.vip")) {
            return plugin.getConfig().getInt("max-homes.vip", 5);
        }
        return plugin.getConfig().getInt("max-homes.default", 3);
    }
    
    public boolean canSetHome(Player player) {
        PlayerHomeData data = getPlayerData(player.getUniqueId());
        return data.getHomeCount() < getMaxHomes(player);
    }
    
    public boolean isOnCooldown(Player player) {
        if (player.hasPermission("dbadvancedhome.bypass.cooldown")) {
            return false;
        }
        PlayerHomeData data = getPlayerData(player.getUniqueId());
        long cooldown = plugin.getConfig().getLong("teleport-cooldown", 3) * 1000;
        return System.currentTimeMillis() - data.getLastTeleport() < cooldown;
    }
    
    public long getRemainingCooldown(Player player) {
        PlayerHomeData data = getPlayerData(player.getUniqueId());
        long cooldown = plugin.getConfig().getLong("teleport-cooldown", 3) * 1000;
        long remaining = cooldown - (System.currentTimeMillis() - data.getLastTeleport());
        return Math.max(0, remaining / 1000);
    }
    
    public void setLastTeleport(Player player) {
        PlayerHomeData data = getPlayerData(player.getUniqueId());
        data.setLastTeleport(System.currentTimeMillis());
    }
    
    public void saveHomes() {
        homesConfig = new YamlConfiguration();
        
        for (Map.Entry<UUID, PlayerHomeData> entry : playerData.entrySet()) {
            UUID playerId = entry.getKey();
            PlayerHomeData data = entry.getValue();
            
            String path = playerId.toString();
            for (Home home : data.getHomes().values()) {
                String homePath = path + "." + home.getName();
                homesConfig.set(homePath + ".world", home.getWorld());
                homesConfig.set(homePath + ".x", home.getX());
                homesConfig.set(homePath + ".y", home.getY());
                homesConfig.set(homePath + ".z", home.getZ());
                homesConfig.set(homePath + ".yaw", home.getYaw());
                homesConfig.set(homePath + ".pitch", home.getPitch());
                homesConfig.set(homePath + ".icon", home.getIcon());
            }
        }
        
        try {
            homesConfig.save(homesFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void loadHomes() {
        playerData.clear();
        homesConfig = YamlConfiguration.loadConfiguration(homesFile);
        
        for (String uuidStr : homesConfig.getKeys(false)) {
            UUID playerId = UUID.fromString(uuidStr);
            PlayerHomeData data = new PlayerHomeData(playerId);
            
            ConfigurationSection playerSection = homesConfig.getConfigurationSection(uuidStr);
            if (playerSection != null) {
                for (String homeName : playerSection.getKeys(false)) {
                    String homePath = uuidStr + "." + homeName;
                    Home home = new Home(
                        homeName,
                        homesConfig.getString(homePath + ".world"),
                        homesConfig.getDouble(homePath + ".x"),
                        homesConfig.getDouble(homePath + ".y"),
                        homesConfig.getDouble(homePath + ".z"),
                        (float) homesConfig.getDouble(homePath + ".yaw"),
                        (float) homesConfig.getDouble(homePath + ".pitch"),
                        homesConfig.getString(homePath + ".icon", "RED_BED")
                    );
                    data.addHome(home);
                }
            }
            
            playerData.put(playerId, data);
        }
    }
    
    public void clearPlayerHomes(UUID playerId) {
        playerData.remove(playerId);
    }
    
    public List<PlayerHomeData> getAllPlayerData() {
        return new ArrayList<>(playerData.values());
    }
}