package me.dev.levelingspear;

import me.dev.levelingspear.commands.GetSpearCommand;
import me.dev.levelingspear.commands.GiveSpearCommand;
import me.dev.levelingspear.listeners.CraftBlockListener;
import me.dev.levelingspear.listeners.SpearKillListener;
import me.dev.levelingspear.managers.LevelManager;
import me.dev.levelingspear.managers.SpearManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class LevelingSpear extends JavaPlugin {

    private static LevelingSpear instance;

    private SpearManager spearManager;
    private LevelManager levelManager;

    @Override
    public void onEnable() {

        instance = this;

        // Save default config
        saveDefaultConfig();

        // ================= MANAGERS =================
        spearManager = new SpearManager(this);
        levelManager = new LevelManager(this, spearManager);

        // ================= LISTENERS =================
        getServer().getPluginManager().registerEvents(
                new CraftBlockListener(this),
                this
        );

        getServer().getPluginManager().registerEvents(
                new SpearKillListener(this, spearManager, levelManager),
                this
        );

        // ================= COMMANDS =================
        if (getCommand("getspear") != null) {
            GetSpearCommand getSpearCommand =
                    new GetSpearCommand(this, spearManager);

            getCommand("getspear").setExecutor(getSpearCommand);
            getCommand("getspear").setTabCompleter(getSpearCommand);
        }

        if (getCommand("givespear") != null) {
            GiveSpearCommand giveSpearCommand =
                    new GiveSpearCommand(this, spearManager);

            getCommand("givespear").setExecutor(giveSpearCommand);
            getCommand("givespear").setTabCompleter(giveSpearCommand);
        }

        getLogger().info("LevelingSpear enabled successfully.");
    }

    @Override
    public void onDisable() {
        getLogger().info("LevelingSpear disabled.");
        instance = null;
    }

    /* ================= GETTERS ================= */

    public static LevelingSpear getInstance() {
        return instance;
    }

    public SpearManager getSpearManager() {
        return spearManager;
    }

    public LevelManager getLevelManager() {
        return levelManager;
    }
}