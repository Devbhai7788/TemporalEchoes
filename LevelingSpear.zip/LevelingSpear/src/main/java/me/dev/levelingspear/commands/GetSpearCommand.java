package me.dev.levelingspear.commands;

import me.dev.levelingspear.LevelingSpear;
import me.dev.levelingspear.manager.SpearManager;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class GetSpearCommand implements CommandExecutor, TabCompleter {

    private final LevelingSpear plugin;
    private final SpearManager spearManager;

    private final List<String> spearTypes = Arrays.asList(
            "wooden", "stone", "iron", "golden", "diamond", "netherite"
    );

    public GetSpearCommand(LevelingSpear plugin, SpearManager spearManager) {
        this.plugin = plugin;
        this.spearManager = spearManager;
    }

    /* ================= COMMAND ================= */

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage(color(
                    plugin.getConfig().getString("messages.player-only")
            ));
            return true;
        }

        if (!player.isOp()) {
            player.sendMessage(color(
                    plugin.getConfig().getString("messages.no-permission")
            ));
            return true;
        }

        if (args.length != 1) {
            player.sendMessage(color(
                    plugin.getConfig().getString("messages.getspear-usage")
            ));
            return true;
        }

        String type = args[0].toLowerCase();

        if (!spearTypes.contains(type)) {
            player.sendMessage(color(
                    plugin.getConfig().getString("messages.invalid-spear-type")
            ));
            return true;
        }

        player.getInventory().addItem(
                spearManager.createSpear(type)
        );

        player.sendMessage(color(
                plugin.getConfig()
                        .getString("messages.getspear-success")
                        .replace("%type%", type)
        ));

        return true;
    }

    /* ================= TAB COMPLETE ================= */

    @Override
    public List<String> onTabComplete(CommandSender sender,
                                      Command command,
                                      String alias,
                                      String[] args) {

        if (args.length == 1) {
            return spearTypes;
        }

        return null;
    }

    /* ================= COLOR ================= */

    private String color(String s) {
        return s == null ? "" :
                org.bukkit.ChatColor.translateAlternateColorCodes('&', s);
    }
}