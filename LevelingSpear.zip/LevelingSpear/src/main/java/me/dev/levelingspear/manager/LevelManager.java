package me.dev.levelingspear.managers;

import me.dev.levelingspear.LevelingSpear;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class LevelManager {

    private final LevelingSpear plugin;
    private final SpearManager spearManager;

    public LevelManager(LevelingSpear plugin, SpearManager spearManager) {
        this.plugin = plugin;
        this.spearManager = spearManager;
    }

    /* ==========================================================
       HANDLE KILL
    ========================================================== */
    public void handleKill(Player killer, ItemStack spear) {

        if (!spearManager.isLevelingSpear(spear)) return;

        String currentTier = spearManager.getTier(spear);
        int currentKills = spearManager.getKills(spear);

        int newKills = currentKills + 1;
        spearManager.setKills(spear, newKills);

        // Check upgrade requirement
        if (canUpgrade(currentTier, newKills)) {
            upgradeSpear(killer, spear, currentTier);
        } else {
            spearManager.updateLore(spear);
        }
    }

    /* ==========================================================
       CHECK IF CAN UPGRADE
    ========================================================== */
    private boolean canUpgrade(String tier, int kills) {

        FileConfiguration config = plugin.getConfig();

        int required = config.getInt("upgrade.kills." + tier.toLowerCase());

        // 0 means no further upgrade
        if (required <= 0) return false;

        return kills >= required;
    }

    /* ==========================================================
       UPGRADE SPEAR
    ========================================================== */
    private void upgradeSpear(Player player, ItemStack spear, String currentTier) {

        List<String> order = plugin.getConfig().getStringList("upgrade.order");

        int index = order.indexOf(currentTier.toLowerCase());

        if (index == -1) return;
        if (index + 1 >= order.size()) return;

        String nextTier = order.get(index + 1);

        // Upgrade spear
        spearManager.setTier(spear, nextTier);
        spearManager.setKills(spear, 0);
        spearManager.updateLore(spear);

        // Message
        String msg = plugin.getConfig()
                .getString("messages.level-up", "&aYour spear upgraded to %tier%!")
                .replace("%tier%", capitalize(nextTier));

        player.sendMessage(color(msg));
    }

    /* ==========================================================
       UTIL
    ========================================================== */
    private String capitalize(String s) {
        return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}