package me.dev.levelingspear.command;

import me.dev.levelingspear.LevelingSpear;
import me.dev.levelingspear.manager.SpearManager;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GiveSpearCommand implements CommandExecutor, TabCompleter {

    private final LevelingSpear plugin;
    private final SpearManager spearManager;

    private final List<String> spearTypes = Arrays.asList(
            "wooden", "stone", "iron", "golden", "diamond", "netherite"
    );

    public GiveSpearCommand(LevelingSpear plugin, SpearManager spearManager) {
        this.plugin = plugin;
        this.spearManager = spearManager;
    }

    /* ================= COMMAND ================= */

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        if (!player.isOp()) {
            player.sendMessage(color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        if (args.length != 2) {
            player.sendMessage(color(plugin.getConfig().getString("messages.givespear-usage")));
            return true;
        }

        String targetArg = args[0];
        String type = args[1].toLowerCase();

        if (!spearTypes.contains(type)) {
            player.sendMessage(color(plugin.getConfig().getString("messages.invalid-spear-type")));
            return true;
        }

        /* ================= GIVE TO EVERYONE ================= */
        if (targetArg.equalsIgnoreCase("&e")) {

            for (Player online : Bukkit.getOnlinePlayers()) {
                online.getInventory().addItem(spearManager.createSpear(type));
            }

            player.sendMessage(color(
                    plugin.getConfig()
                            .getString("messages.givespear-everyone")
                            .replace("%type%", type)
            ));

            return true;
        }

        /* ================= GIVE TO SINGLE PLAYER ================= */
        Player target = Bukkit.getPlayerExact(targetArg);

        if (target == null) {
            player.sendMessage(color(plugin.getConfig().getString("messages.player-not-found")));
            return true;
        }

        target.getInventory().addItem(spearManager.createSpear(type));

        player.sendMessage(color(
                plugin.getConfig()
                        .getString("messages.givespear-success")
                        .replace("%player%", target.getName())
                        .replace("%type%", type)
        ));

        target.sendMessage(color(
                plugin.getConfig()
                        .getString("messages.givespear-received")
                        .replace("%type%", type)
        ));

        return true;
    }

    /* ================= TAB COMPLETE ================= */

    @Override
    public List<String> onTabComplete(CommandSender sender,
                                      Command command,
                                      String alias,
                                      String[] args) {

        if (args.length == 1) {

            List<String> list = new ArrayList<>();

            list.add("&e"); // everyone selector

            for (Player p : Bukkit.getOnlinePlayers()) {
                list.add(p.getName());
            }

            return list;
        }

        if (args.length == 2) {
            return spearTypes;
        }

        return null;
    }

    /* ================= COLOR ================= */

    private String color(String s) {
        return s == null ? "" :
                org.bukkit.ChatColor.translateAlternateColorCodes('&', s);
    }
}