package me.dev.levelingspear.managers;

import me.dev.levelingspear.LevelingSpear;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class SpearManager {

    private final LevelingSpear plugin;

    private final NamespacedKey tierKey;
    private final NamespacedKey killsKey;

    public SpearManager(LevelingSpear plugin) {
        this.plugin = plugin;
        this.tierKey = new NamespacedKey(plugin, "spear-tier");
        this.killsKey = new NamespacedKey(plugin, "spear-kills");
    }

    /* =====================================================
     * CREATE SPEAR
     * ===================================================== */
    public ItemStack createSpear(String tier) {

        Material material = Material.matchMaterial("SPEAR");
        if (material == null) {
            Bukkit.getLogger().severe("SPEAR material not found in this version!");
            return null;
        }

        ItemStack spear = new ItemStack(material);
        ItemMeta meta = spear.getItemMeta();
        if (meta == null) return spear;

        PersistentDataContainer container = meta.getPersistentDataContainer();
        container.set(tierKey, PersistentDataType.STRING, tier.toLowerCase());
        container.set(killsKey, PersistentDataType.INTEGER, 0);

        meta.setDisplayName(color(
                plugin.getConfig().getString("spear.name-format", "&b%tier% Spear")
                        .replace("%tier%", capitalize(tier))
        ));

        updateLore(meta, tier, 0);

        spear.setItemMeta(meta);
        return spear;
    }

    /* =====================================================
     * CHECK IF CUSTOM SPEAR
     * ===================================================== */
    public boolean isLevelingSpear(ItemStack item) {
        if (item == null || item.getType() != Material.matchMaterial("SPEAR")) return false;
        if (!item.hasItemMeta()) return false;

        PersistentDataContainer container =
                item.getItemMeta().getPersistentDataContainer();

        return container.has(tierKey, PersistentDataType.STRING);
    }

    /* =====================================================
     * HANDLE KILL
     * ===================================================== */
    public ItemStack handleKill(ItemStack spear) {

        if (!isLevelingSpear(spear)) return spear;

        ItemMeta meta = spear.getItemMeta();
        PersistentDataContainer container = meta.getPersistentDataContainer();

        String tier = container.get(tierKey, PersistentDataType.STRING);
        int kills = container.get(killsKey, PersistentDataType.INTEGER);

        kills++;
        container.set(killsKey, PersistentDataType.INTEGER, kills);

        int required = plugin.getConfig()
                .getInt("upgrade.kills." + tier.toLowerCase(), -1);

        // If tier has upgrade
        if (required > 0 && kills >= required) {

            String nextTier = getNextTier(tier);
            if (nextTier != null) {
                container.set(tierKey, PersistentDataType.STRING, nextTier);
                container.set(killsKey, PersistentDataType.INTEGER, 0);
                tier = nextTier;
                kills = 0;
            }
        }

        updateLore(meta, tier, kills);
        spear.setItemMeta(meta);

        return spear;
    }

    /* =====================================================
     * GET NEXT TIER
     * ===================================================== */
    private String getNextTier(String current) {

        List<String> order = plugin.getConfig().getStringList("upgrade.order");

        for (int i = 0; i < order.size(); i++) {
            if (order.get(i).equalsIgnoreCase(current)) {
                if (i + 1 < order.size()) {
                    return order.get(i + 1);
                }
            }
        }

        return null; // max tier reached
    }

    /* =====================================================
     * UPDATE LORE
     * ===================================================== */
    private void updateLore(ItemMeta meta, String tier, int kills) {

        List<String> lore = new ArrayList<>();

        ConfigurationSection section =
                plugin.getConfig().getConfigurationSection("spear.lore");

        if (section != null) {
            for (String line : section.getStringList("format")) {
                line = line.replace("%tier%", capitalize(tier));
                line = line.replace("%kills%", String.valueOf(kills));
                lore.add(color(line));
            }
        }

        meta.setLore(lore);
    }

    /* =====================================================
     * UTIL
     * ===================================================== */
    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String capitalize(String s) {
        return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase();
    }
}