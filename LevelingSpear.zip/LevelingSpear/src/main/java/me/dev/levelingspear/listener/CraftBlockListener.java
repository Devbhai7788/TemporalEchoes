package me.dev.levelingspear.listeners;

import me.dev.levelingspear.LevelingSpear;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.ItemStack;

public class CraftBlockListener implements Listener {

    private final LevelingSpear plugin;

    public CraftBlockListener(LevelingSpear plugin) {
        this.plugin = plugin;
    }

    /* =========================================
       BLOCK CRAFTING
       ========================================= */
    @EventHandler
    public void onCraft(CraftItemEvent event) {

        if (!plugin.getConfig().getBoolean("block-system.block-crafting")) return;
        if (event.getRecipe() == null) return;

        ItemStack result = event.getRecipe().getResult();
        if (result == null) return;

        if (isSpear(result)) {
            event.setCancelled(true);

            if (event.getWhoClicked() instanceof Player player) {
                player.sendMessage(color(
                        plugin.getConfig().getString("prefix")
                                + plugin.getConfig().getString("messages.spear-blocked")
                ));
            }
        }
    }

    /* =========================================
       BLOCK CREATIVE INVENTORY
       ========================================= */
    @EventHandler
    public void onCreative(InventoryCreativeEvent event) {

        if (!plugin.getConfig().getBoolean("block-system.block-creative")) return;

        ItemStack item = event.getCurrentItem();
        if (item == null) return;

        if (isSpear(item)) {
            event.setCancelled(true);
        }
    }

    /* =========================================
       BLOCK /give COMMAND
       ========================================= */
    @EventHandler
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {

        if (!plugin.getConfig().getBoolean("block-system.block-give-command")) return;

        String message = event.getMessage().toLowerCase();

        if (message.startsWith("/give") && message.contains("spear")) {
            event.setCancelled(true);

            event.getPlayer().sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.spear-blocked")
            ));
        }
    }

    /* =========================================
       BLOCK COMMAND BLOCK
       ========================================= */
    @EventHandler
    public void onServerCommand(ServerCommandEvent event) {

        if (!plugin.getConfig().getBoolean("block-system.block-command-block")) return;

        String command = event.getCommand().toLowerCase();

        if (command.startsWith("give") && command.contains("spear")) {
            event.setCancelled(true);
        }
    }

    /* =========================================
       CHECK IF ITEM IS SPEAR
       ========================================= */
    private boolean isSpear(ItemStack item) {
        if (item == null) return false;

        // If official SPEAR material exists in your version
        try {
            return item.getType().name().contains("SPEAR");
        } catch (Exception e) {
            return false;
        }
    }

    /* =========================================
       COLOR UTIL
       ========================================= */
    private String color(String s) {
        return s == null ? "" :
                ChatColor.translateAlternateColorCodes('&', s);
    }
}