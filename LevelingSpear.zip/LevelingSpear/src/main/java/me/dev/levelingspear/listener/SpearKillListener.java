package me.dev.levelingspear.listener;

import me.dev.levelingspear.LevelingSpear;
import me.dev.levelingspear.manager.SpearManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

public class SpearKillListener implements Listener {

    private final LevelingSpear plugin;
    private final SpearManager spearManager;

    public SpearKillListener(LevelingSpear plugin, SpearManager spearManager) {
        this.plugin = plugin;
        this.spearManager = spearManager;
    }

    /* =====================================================
       HANDLE PLAYER KILL
    ===================================================== */
    @EventHandler
    public void onKill(PlayerDeathEvent event) {

        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) return;

        ItemStack weapon = killer.getInventory().getItemInMainHand();
        if (weapon == null) return;

        // Only continue if this is our custom spear
        if (!spearManager.isLevelingSpear(weapon)) return;

        // Let SpearManager handle kill + upgrade internally
        spearManager.handleKill(weapon);
    }
}