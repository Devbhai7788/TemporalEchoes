package me.dev.levelingspear.listeners;

import me.dev.levelingspear.LevelingSpear;
import me.dev.levelingspear.managers.SpearManager;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

public class SpearKillListener implements Listener {

    private final LevelingSpear plugin;
    private final SpearManager spearManager;

    public SpearKillListener(LevelingSpear plugin, SpearManager spearManager) {
        this.plugin = plugin;
        this.spearManager = spearManager;
    }

    @EventHandler
    public void onKill(PlayerDeathEvent event) {

        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) return;

        ItemStack weapon = killer.getInventory().getItemInMainHand();

        // Not our spear
        if (!spearManager.isLevelingSpear(weapon)) return;

        // Get current tier
        String tier = spearManager.getTier(weapon);
        if (tier == null) return;

        // Add kill
        int kills = spearManager.addKill(weapon);

        // Required kills from config
        int required = plugin.getConfig()
                .getInt("upgrade.kills-required." + tier, 5);

        // Send progress message
        String progressMsg = plugin.getConfig()
                .getString("messages.kill-progress",
                        "&7Kills: &e%kills%&7/&c%required%");

        killer.sendMessage(color(progressMsg
                .replace("%kills%", String.valueOf(kills))
                .replace("%required%", String.valueOf(required))));

        // Check upgrade
        if (kills >= required) {

            String nextTier = spearManager.getNextTier(tier);
            if (nextTier == null) {
                killer.sendMessage(color(
                        plugin.getConfig().getString(
                                "messages.max-level",
                                "&aYour spear is already max level!"
                        )));
                return;
            }

            spearManager.upgradeSpear(weapon, nextTier);

            killer.sendMessage(color(
                    plugin.getConfig().getString(
                            "messages.upgraded",
                            "&aYour spear upgraded to &e%tier%!")
                            .replace("%tier%", nextTier.toUpperCase())
            ));
        }
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}