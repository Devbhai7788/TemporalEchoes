package me.dev.levelingspear.listener;

import me.dev.levelingspear.LevelingSpear;
import me.dev.levelingspear.manager.LevelManager;
import me.dev.levelingspear.manager.SpearManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;

public class SpearKillListener implements Listener {

    private final LevelingSpear plugin;
    private final SpearManager spearManager;
    private final LevelManager levelManager;

    public SpearKillListener(LevelingSpear plugin,
                             SpearManager spearManager,
                             LevelManager levelManager) {
        this.plugin = plugin;
        this.spearManager = spearManager;
        this.levelManager = levelManager;
    }

    @EventHandler
    public void onKill(PlayerDeathEvent event) {

        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) return;

        ItemStack weapon = killer.getInventory().getItemInMainHand();

        if (weapon == null) return;

        // Only handle our custom spear
        if (!spearManager.isLevelingSpear(weapon)) return;

        // Delegate everything to LevelManager
        levelManager.handleKill(killer, weapon);
    }
}