package me.db.dbadvancedhome.commands;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DelHomeCommand implements CommandExecutor {

    private final DBAdvancedHome plugin;

    public DelHomeCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.player-only")
            ));
            return true;
        }

        if (args.length != 1) {
            player.sendMessage(ChatColor.RED + "Usage: /delhome <number>");
            return true;
        }

        int homeNumber;
        try {
            homeNumber = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Home number must be a number.");
            return true;
        }

        if (!plugin.getHomeManager().hasHome(player.getUniqueId(), homeNumber)) {
            player.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-home")
            ));
            return true;
        }

        plugin.getHomeManager().deleteHome(player.getUniqueId(), homeNumber);

        player.sendMessage(ChatColor.translateAlternateColorCodes(
                '&',
                plugin.getConfig().getString("prefix")
                        + plugin.getConfig().getString("messages.home-deleted")
        ));
        return true;
    }
}