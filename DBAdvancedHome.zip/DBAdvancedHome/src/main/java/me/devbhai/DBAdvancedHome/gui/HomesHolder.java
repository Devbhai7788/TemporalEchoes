package me.db.dbadvancedhome.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class HomesHolder implements InventoryHolder {

    @Override
    public Inventory getInventory() {
        return null;
    }
}