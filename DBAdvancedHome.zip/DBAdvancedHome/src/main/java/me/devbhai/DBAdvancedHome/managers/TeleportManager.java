package me.db.dbadvancedhome.managers;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class TeleportManager {

    private final DBAdvancedHome plugin;
    private final Set<UUID> teleporting = new HashSet<>();

    public TeleportManager(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }

    public boolean isTeleporting(Player player) {
        return teleporting.contains(player.getUniqueId());
    }

    public void startTeleport(Player player, Location target, String nameForMessage) {

        if (teleporting.contains(player.getUniqueId())) {
            player.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.already-teleporting")
            ));
            return;
        }

        int delay = plugin.getConfig().getInt("teleport.delay");
        teleporting.add(player.getUniqueId());

        // Countdown message
        String countdown = plugin.getConfig().getString("teleport.countdown-message")
                .replace("%time%", String.valueOf(delay));
        player.sendMessage(color(
                plugin.getConfig().getString("prefix") + countdown
        ));

        new BukkitRunnable() {
            @Override
            public void run() {

                // Cancelled by movement
                if (!teleporting.contains(player.getUniqueId())) {
                    cancel();
                    return;
                }

                teleporting.remove(player.getUniqueId());
                player.teleport(target);

                // Sound
                try {
                    Sound sound = Sound.valueOf(
                            plugin.getConfig().getString("sounds.teleport")
                    );
                    player.playSound(player.getLocation(), sound, 1f, 1f);
                } catch (Exception ignored) {}

                // Message
                String msg = plugin.getConfig().getString("messages.teleported")
                        .replace("%name%", nameForMessage);

                player.sendMessage(color(
                        plugin.getConfig().getString("prefix") + msg
                ));
            }
        }.runTaskLater(plugin, delay * 20L);
    }

    public void cancelTeleport(Player player) {
        teleporting.remove(player.getUniqueId());
    }

    private String color(String text) {
        return text == null ? "" :
                org.bukkit.ChatColor.translateAlternateColorCodes('&', text);
    }
}