package me.db.dbadvancedhome.managers;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class TeleportManager {

    private final DBAdvancedHome plugin;

    private final Set<UUID> teleporting = new HashSet<>();
    private final Map<UUID, BossBar> bossBars = new HashMap<>();

    public TeleportManager(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }

    /* =====================================================
     * CHECK
     * ===================================================== */
    public boolean isTeleporting(Player player) {
        return teleporting.contains(player.getUniqueId());
    }

    /* =====================================================
     * START TELEPORT
     * ===================================================== */
    public void startTeleport(Player player, Location target, String nameForMessage) {

        if (teleporting.contains(player.getUniqueId())) {
            player.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.already-teleporting")
            ));
            return;
        }

        int delay = plugin.getConfig().getInt("teleport.delay", 5);
        teleporting.add(player.getUniqueId());

        /* ================= CHAT COUNTDOWN ================= */
        String countdown = plugin.getConfig()
                .getString("teleport.countdown-message", "&7Teleporting in &f%time%&7 seconds")
                .replace("%time%", String.valueOf(delay));

        player.sendMessage(color(
                plugin.getConfig().getString("prefix") + countdown
        ));

        /* ================= BOSSBAR ================= */
        BossBar bar = Bukkit.createBossBar(
                color(plugin.getConfig().getString("teleport.bossbar.text", "&aTeleporting...")),
                BarColor.valueOf(plugin.getConfig().getString("teleport.bossbar.color", "GREEN")),
                BarStyle.valueOf(plugin.getConfig().getString("teleport.bossbar.style", "SOLID"))
        );

        bar.addPlayer(player);
        bar.setProgress(1.0);
        bossBars.put(player.getUniqueId(), bar);

        /* ================= TIMER ================= */
        new BukkitRunnable() {

            int timeLeft = delay;

            @Override
            public void run() {

                if (!teleporting.contains(player.getUniqueId())) {
                    removeBossBar(player);
                    cancel();
                    return;
                }

                double progress = (double) timeLeft / delay;
                bar.setProgress(Math.max(0, progress));

                timeLeft--;

                if (timeLeft < 0) {
                    teleporting.remove(player.getUniqueId());
                    removeBossBar(player);

                    /* ================= TELEPORT ================= */
                    player.teleport(target);

                    playSound(player, "teleport");

                    /* ================= CHAT MESSAGE ================= */
                    String msg = plugin.getConfig()
                            .getString("messages.teleported", "&aTeleported to &f%name%")
                            .replace("%name%", nameForMessage);

                    player.sendMessage(color(
                            plugin.getConfig().getString("prefix") + msg
                    ));

                    /* ================= TITLE ================= */
                    sendTeleportTitle(player);

                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    /* =====================================================
     * CANCEL TELEPORT
     * ===================================================== */
    public void cancelTeleport(Player player) {
        teleporting.remove(player.getUniqueId());
        removeBossBar(player);
    }

    /* =====================================================
     * REMOVE BOSSBAR
     * ===================================================== */
    private void removeBossBar(Player player) {
        BossBar bar = bossBars.remove(player.getUniqueId());
        if (bar != null) {
            bar.removeAll();
        }
    }

    /* =====================================================
     * TITLE HANDLER
     * ===================================================== */
    private void sendTeleportTitle(Player player) {

        String title = plugin.getConfig().getString("titles.teleport.title");
        String subtitle = plugin.getConfig().getString("titles.teleport.subtitle");

        int fadeIn  = plugin.getConfig().getInt("titles.teleport.fade-in", 10);
        int stay    = plugin.getConfig().getInt("titles.teleport.stay", 40);
        int fadeOut = plugin.getConfig().getInt("titles.teleport.fade-out", 10);

        if (title == null && subtitle == null) return;

        player.sendTitle(
                color(title),
                color(subtitle),
                fadeIn,
                stay,
                fadeOut
        );
    }

    /* =====================================================
     * SOUND UTIL
     * ===================================================== */
    private void playSound(Player player, String key) {
        String soundName = plugin.getConfig().getString("sounds." + key);
        if (soundName == null) return;

        try {
            player.playSound(
                    player.getLocation(),
                    Sound.valueOf(soundName),
                    1f,
                    1f
            );
        } catch (Exception ignored) {}
    }

    /* =====================================================
     * COLOR UTIL
     * ===================================================== */
    private String color(String text) {
        return text == null ? "" :
                ChatColor.translateAlternateColorCodes('&', text);
    }
}