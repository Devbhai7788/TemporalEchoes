package me.db.dbadvancedhome.commands;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DBReloadCommand implements CommandExecutor {

    private final DBAdvancedHome plugin;

    public DBReloadCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.player-only")
            ));
            return true;
        }

        if (!player.hasPermission("dbadvancedhome.admin")) {
            player.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-permission")
            ));
            return true;
        }

        plugin.reloadConfig();

        player.sendMessage(ChatColor.translateAlternateColorCodes(
                '&',
                plugin.getConfig().getString("prefix")
                        + "&aConfiguration reloaded successfully."
        ));
        return true;
    }
}