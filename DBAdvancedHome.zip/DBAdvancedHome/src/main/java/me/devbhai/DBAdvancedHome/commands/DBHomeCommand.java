package me.db.dbadvancedhome.commands;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DBHomeCommand implements CommandExecutor {

    private final DBAdvancedHome plugin;

    public DBHomeCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player admin)) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.player-only")
            ));
            return true;
        }

        if (!admin.hasPermission("dbadvancedhome.admin")) {
            admin.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-permission")
            ));
            return true;
        }

        if (args.length != 1) {
            admin.sendMessage(ChatColor.RED + "Usage: /dbhome <player>");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);

        if (!plugin.getHomeManager().getHomes(target.getUniqueId()).iterator().hasNext()) {
            admin.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-home")
            ));
            return true;
        }

        // Open admin view GUI (IMPORTANT)
        plugin.getGUIListener().openAdminGUI(admin, target.getUniqueId());
        return true;
    }
}