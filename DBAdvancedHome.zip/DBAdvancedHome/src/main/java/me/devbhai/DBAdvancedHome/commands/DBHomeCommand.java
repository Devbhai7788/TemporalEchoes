package me.db.dbadvancedhome.commands;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.gui.AdminViewGUI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class DBHomeCommand implements CommandExecutor {

    private final DBAdvancedHome plugin;

    public DBHomeCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        // Player only
        if (!(sender instanceof Player admin)) {
            sender.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.player-only")
            ));
            return true;
        }

        // Permission
        if (!admin.hasPermission("dbadvancedhome.admin")) {
            admin.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-permission")
            ));
            return true;
        }

        // Usage
        if (args.length != 1) {
            admin.sendMessage(ChatColor.RED + "Usage: /dbhome <player>");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        UUID targetUUID = target.getUniqueId();

        // No homes
        if (plugin.getHomeManager().getHomes(targetUUID).isEmpty()) {
            admin.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-home")
            ));
            return true;
        }

        // Open admin GUI
        plugin.getGUIListener().openAdminGUI(admin, targetUUID);

        // GUI open sound
        playSound(admin, "gui-open");

        return true;
    }

    /* ---------------- SOUND ---------------- */

    private void playSound(Player player, String key) {
        String soundName = plugin.getConfig().getString("sounds." + key);
        if (soundName == null) return;

        try {
            player.playSound(
                    player.getLocation(),
                    Sound.valueOf(soundName),
                    1f,
                    1f
            );
        } catch (IllegalArgumentException ignored) {
        }
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}