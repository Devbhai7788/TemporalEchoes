package me.db.dbadvancedhome.commands;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DBHomeCommand implements CommandExecutor {

    private final DBAdvancedHome plugin;

    public DBHomeCommand(DBAdvancedHome plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        // Player-only check
        if (!(sender instanceof Player admin)) {
            sender.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.player-only")
            ));
            return true;
        }

        // Permission check
        if (!admin.hasPermission("dbadvancedhome.admin")) {
            admin.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-permission")
            ));
            return true;
        }

        // Usage check
        if (args.length != 1) {
            admin.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.dbhome-usage")
            ));
            return true;
        }

        // Target player (offline-safe)
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);

        if (target.getName() == null) {
            admin.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + "&cPlayer not found."
            ));
            return true;
        }

        // ✅ SAFE home existence check
        if (!plugin.getHomeManager().hasAnyHome(target.getUniqueId())) {
            admin.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-home")
            ));
            return true;
        }

        // ✅ OPEN ADMIN GUI (CORRECT WAY)
        plugin.getGUIListener().openAdminGUI(admin, target.getUniqueId());
        return true;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}