package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.HomeManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

public class AdminViewGUI {

    public static void open(Player admin, UUID targetUUID, DBAdvancedHome plugin) {

        OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);

        int rows = plugin.getConfig().getInt("gui.rows");

        // 👉 TITLE: "<PlayerName>'s Homes"
        String title = org.bukkit.ChatColor.translateAlternateColorCodes(
                '&',
                target.getName() + "'s Homes"
        );

        Inventory inv = Bukkit.createInventory(null, rows * 9, title);

        HomeManager homeManager = plugin.getHomeManager();
        int maxHomes = plugin.getConfig().getInt("max-home-limit");

        for (int i = 1; i <= maxHomes; i++) {

            if (!homeManager.hasHome(targetUUID, i)) continue;

            ConfigurationSection sec =
                    plugin.getConfig().getConfigurationSection("gui.items.home-set");

            ItemStack item = new ItemStack(Material.valueOf(sec.getString("material")));
            ItemMeta meta = item.getItemMeta();

            meta.setDisplayName(
                    color(sec.getString("name")
                            .replace("%number%", String.valueOf(i)))
            );
            meta.setLore(colorList(sec.getStringList("lore")));

            item.setItemMeta(meta);
            inv.setItem(i - 1, item);
        }

        admin.openInventory(inv);
    }

    /* ---------------- utils ---------------- */

    private static String color(String s) {
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', s);
    }

    private static List<String> colorList(List<String> list) {
        return list.stream().map(AdminViewGUI::color).toList();
    }
}