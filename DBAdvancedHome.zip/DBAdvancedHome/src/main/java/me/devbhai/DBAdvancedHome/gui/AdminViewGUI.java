package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.HomeManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class AdminViewGUI {

    // SAME striped layout as player GUI
    private static final int[] HOME_SLOTS = {
            // Row 2
            10, 11, 12, 13, 14, 15, 16,
            // Row 4
            28, 29, 30, 31, 32, 33, 34
    };

    public static void open(Player admin, UUID targetUUID, DBAdvancedHome plugin) {

        OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);

        ConfigurationSection gui = plugin.getConfig().getConfigurationSection("gui");
        if (gui == null) return;

        ConfigurationSection items = gui.getConfigurationSection("items");
        if (items == null) return;

        int rows = gui.getInt("rows", 6);

        // 🔒 SAFE PLAYER NAME
        String playerName = target.getName() != null ? target.getName() : "Player";
        String title = color(playerName + "'s Homes");

        Inventory inv = Bukkit.createInventory(null, rows * 9, title);

        /* ---------------- FILLER GLASS ---------------- */
        ConfigurationSection filler = gui.getConfigurationSection("filler");
        if (filler == null) return;

        ItemStack fillerItem = new ItemStack(
                Material.valueOf(filler.getString("material"))
        );
        ItemMeta fm = fillerItem.getItemMeta();
        fm.setDisplayName(color(filler.getString("name")));
        fillerItem.setItemMeta(fm);

        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, fillerItem);
        }

        /* ---------------- HOMES ---------------- */
        HomeManager homeManager = plugin.getHomeManager();

        for (int i = 0; i < HOME_SLOTS.length; i++) {

            int homeNumber = i + 1;
            int slot = HOME_SLOTS[i];

            // Admin sees ONLY existing homes
            if (!homeManager.hasHome(targetUUID, homeNumber)) continue;

            ItemStack item = buildItem(
                    items.getConfigurationSection("home-set"),
                    homeNumber
            );

            inv.setItem(slot, item);
        }

        admin.openInventory(inv);
    }

    /* ---------------- ITEM BUILDER ---------------- */

    private static ItemStack buildItem(ConfigurationSection section, int number) {

        if (section == null) return new ItemStack(Material.BARRIER);

        Material material = Material.valueOf(section.getString("material"));
        String name = section.getString("name");
        List<String> lore = section.getStringList("lore");

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(
                color(name.replace("%number%", String.valueOf(number)))
        );

        if (lore != null && !lore.isEmpty()) {
            meta.setLore(
                    lore.stream()
                            .map(AdminViewGUI::color)
                            .collect(Collectors.toList())
            );
        }

        item.setItemMeta(meta);
        return item;
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}