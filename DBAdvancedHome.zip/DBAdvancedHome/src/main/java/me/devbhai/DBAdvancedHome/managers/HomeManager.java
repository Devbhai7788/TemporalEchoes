package me.db.dbadvancedhome.managers;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class HomeManager {

    private final JavaPlugin plugin;
    private final File homesFolder;

    public HomeManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.homesFolder = new File(plugin.getDataFolder(), "homes");

        if (!homesFolder.exists()) {
            homesFolder.mkdirs();
        }
    }

    /* ----------------------------------------------------
     * File handling
     * ---------------------------------------------------- */

    private File getPlayerFile(UUID uuid) {
        return new File(homesFolder, uuid.toString() + ".yml");
    }

    private YamlConfiguration getConfig(UUID uuid) {
        File file = getPlayerFile(uuid);
        return YamlConfiguration.loadConfiguration(file);
    }

    /* ----------------------------------------------------
     * Home checks
     * ---------------------------------------------------- */

    public boolean hasHome(UUID uuid, int number) {
        YamlConfiguration cfg = getConfig(uuid);
        return cfg.contains("homes." + number);
    }

    /**
     * Used by admin command to check if player has ANY homes
     */
    public boolean hasAnyHome(UUID uuid) {
        YamlConfiguration cfg = getConfig(uuid);

        if (!cfg.contains("homes")) return false;

        ConfigurationSection sec = cfg.getConfigurationSection("homes");
        return sec != null && !sec.getKeys(false).isEmpty();
    }

    /* ----------------------------------------------------
     * Set / Get / Delete
     * ---------------------------------------------------- */

    public void setHome(UUID uuid, int number, Location loc) {
        if (loc == null || loc.getWorld() == null) return;

        YamlConfiguration cfg = getConfig(uuid);

        cfg.set("homes." + number + ".world", loc.getWorld().getName());
        cfg.set("homes." + number + ".x", loc.getX());
        cfg.set("homes." + number + ".y", loc.getY());
        cfg.set("homes." + number + ".z", loc.getZ());
        cfg.set("homes." + number + ".yaw", loc.getYaw());
        cfg.set("homes." + number + ".pitch", loc.getPitch());

        save(uuid, cfg);
    }

    public Location getHome(UUID uuid, int number) {
        YamlConfiguration cfg = getConfig(uuid);

        if (!cfg.contains("homes." + number)) return null;

        String worldName = cfg.getString("homes." + number + ".world");
        if (worldName == null) return null;

        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;

        double x = cfg.getDouble("homes." + number + ".x");
        double y = cfg.getDouble("homes." + number + ".y");
        double z = cfg.getDouble("homes." + number + ".z");
        float yaw = (float) cfg.getDouble("homes." + number + ".yaw");
        float pitch = (float) cfg.getDouble("homes." + number + ".pitch");

        return new Location(world, x, y, z, yaw, pitch);
    }

    public void deleteHome(UUID uuid, int number) {
        YamlConfiguration cfg = getConfig(uuid);

        if (!cfg.contains("homes." + number)) return;

        cfg.set("homes." + number, null);
        save(uuid, cfg);
    }

    /* ----------------------------------------------------
     * Get all homes
     * ---------------------------------------------------- */

    public Set<Integer> getHomes(UUID uuid) {
        YamlConfiguration cfg = getConfig(uuid);
        Set<Integer> homes = new HashSet<>();

        if (!cfg.contains("homes")) return homes;

        ConfigurationSection sec = cfg.getConfigurationSection("homes");
        if (sec == null) return homes;

        for (String key : sec.getKeys(false)) {
            try {
                homes.add(Integer.parseInt(key));
            } catch (NumberFormatException ignored) {
            }
        }

        return homes;
    }

    /* ----------------------------------------------------
     * Save
     * ---------------------------------------------------- */

    private void save(UUID uuid, YamlConfiguration cfg) {
        try {
            cfg.save(getPlayerFile(uuid));
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save homes file for " + uuid);
            e.printStackTrace();
        }
    }
}