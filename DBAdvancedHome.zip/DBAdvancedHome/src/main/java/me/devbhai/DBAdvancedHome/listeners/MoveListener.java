package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MoveListener implements Listener {

    private final DBAdvancedHome plugin;
    private final TeleportManager teleportManager;

    // Store bossbars per player
    private final Map<UUID, BossBar> bossBars = new HashMap<>();

    public MoveListener(DBAdvancedHome plugin, TeleportManager teleportManager) {
        this.plugin = plugin;
        this.teleportManager = teleportManager;
    }

    /* =====================================================
     * START BOSSBAR (CALLED WHEN TELEPORT STARTS)
     * ===================================================== */
    public void startBossBar(Player player) {

        int delay = plugin.getConfig().getInt("teleport.delay", 5);

        String title = ChatColor.translateAlternateColorCodes(
                '&',
                plugin.getConfig().getString(
                        "bossbar.teleport.title",
                        "&aTeleporting in &f%time% &aseconds"
                ).replace("%time%", String.valueOf(delay))
        );

        BossBar bar = Bukkit.createBossBar(
                title,
                BarColor.GREEN,
                BarStyle.SOLID
        );

        bar.addPlayer(player);
        bar.setProgress(1.0);

        bossBars.put(player.getUniqueId(), bar);

        new BukkitRunnable() {
            int timeLeft = delay;

            @Override
            public void run() {

                // ❌ teleport cancelled
                if (!teleportManager.isTeleporting(player)) {
                    removeBossBar(player);
                    cancel();
                    return;
                }

                timeLeft--;

                if (timeLeft <= 0) {
                    removeBossBar(player);
                    cancel();
                    return;
                }

                bar.setTitle(ChatColor.translateAlternateColorCodes(
                        '&',
                        plugin.getConfig().getString("bossbar.teleport.title")
                                .replace("%time%", String.valueOf(timeLeft))
                ));

                bar.setProgress(timeLeft / (double) delay);
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    /* =====================================================
     * REMOVE BOSSBAR
     * ===================================================== */
    private void removeBossBar(Player player) {
        BossBar bar = bossBars.remove(player.getUniqueId());
        if (bar != null) {
            bar.removeAll();
        }
    }

    /* =====================================================
     * MOVE LISTENER (CANCEL ON MOVE)
     * ===================================================== */
    @EventHandler
    public void onMove(PlayerMoveEvent event) {

        if (!plugin.getConfig().getBoolean("teleport.cancel-on-move")) return;

        Player player = event.getPlayer();

        if (!teleportManager.isTeleporting(player)) return;

        // Ignore head rotation
        if (event.getFrom().getX() == event.getTo().getX()
                && event.getFrom().getY() == event.getTo().getY()
                && event.getFrom().getZ() == event.getTo().getZ()) {
            return;
        }

        // ❌ cancel teleport
        teleportManager.cancelTeleport(player);
        removeBossBar(player);

        // message
        player.sendMessage(ChatColor.translateAlternateColorCodes(
                '&',
                plugin.getConfig().getString("prefix")
                        + plugin.getConfig().getString("teleport.cancel-message")
        ));

        // sound
        String soundName = plugin.getConfig().getString("sounds.unset-cancel");
        if (soundName != null) {
            try {
                player.playSound(
                        player.getLocation(),
                        Sound.valueOf(soundName),
                        1f,
                        1f
                );
            } catch (Exception ignored) {}
        }
    }
}