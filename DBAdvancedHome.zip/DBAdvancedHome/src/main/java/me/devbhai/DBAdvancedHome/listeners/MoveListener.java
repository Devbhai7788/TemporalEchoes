package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class MoveListener implements Listener {

    private final DBAdvancedHome plugin;
    private final TeleportManager teleportManager;

    public MoveListener(DBAdvancedHome plugin, TeleportManager teleportManager) {
        this.plugin = plugin;
        this.teleportManager = teleportManager;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {

        if (!plugin.getConfig().getBoolean("teleport.cancel-on-move")) return;

        Player player = event.getPlayer();

        if (!teleportManager.isTeleporting(player)) return;

        // Ignore head rotation
        if (event.getFrom().getX() == event.getTo().getX()
                && event.getFrom().getY() == event.getTo().getY()
                && event.getFrom().getZ() == event.getTo().getZ()) {
            return;
        }

        teleportManager.cancelTeleport(player);

        player.sendMessage(
                org.bukkit.ChatColor.translateAlternateColorCodes('&',
                        plugin.getConfig().getString("prefix")
                                + plugin.getConfig().getString("teleport.cancel-message")
                )
        );
    }
}