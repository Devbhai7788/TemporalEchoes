package me.db.dbadvancedhome;

import me.db.dbadvancedhome.commands.DBHomeCommand;
import me.db.dbadvancedhome.commands.DBReloadCommand;
import me.db.dbadvancedhome.commands.DelHomeCommand;
import me.db.dbadvancedhome.commands.HomeCommand;
import me.db.dbadvancedhome.listeners.GUIListener;
import me.db.dbadvancedhome.listeners.MoveListener;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.plugin.java.JavaPlugin;

public class DBAdvancedHome extends JavaPlugin {

    private static DBAdvancedHome instance;

    private HomeManager homeManager;
    private TeleportManager teleportManager;
    private GUIListener guiListener;

    @Override
    public void onEnable() {
        instance = this;

        // Create config.yml if not exists
        saveDefaultConfig();

        // Managers
        homeManager = new HomeManager(this);
        teleportManager = new TeleportManager(this);

        // GUI Listener (single instance)
        guiListener = new GUIListener(this, homeManager, teleportManager);

        // Register listeners
        getServer().getPluginManager().registerEvents(guiListener, this);
        getServer().getPluginManager().registerEvents(
                new MoveListener(this, teleportManager), this
        );

        // Register commands SAFELY
        if (getCommand("home") != null)
            getCommand("home").setExecutor(new HomeCommand(this));

        if (getCommand("delhome") != null)
            getCommand("delhome").setExecutor(new DelHomeCommand(this));

        if (getCommand("dbhome") != null)
            getCommand("dbhome").setExecutor(new DBHomeCommand(this));

        if (getCommand("dbreload") != null)
            getCommand("dbreload").setExecutor(new DBReloadCommand(this));

        getLogger().info("DBAdvancedHome enabled successfully.");
    }

    @Override
    public void onDisable() {
        getLogger().info("DBAdvancedHome disabled.");
    }

    /* ---------------- GETTERS ---------------- */

    public static DBAdvancedHome getInstance() {
        return instance;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }

    public TeleportManager getTeleportManager() {
        return teleportManager;
    }

    public GUIListener getGUIListener() {
        return guiListener;
    }
}