package me.db.dbadvancedhome;

import me.db.dbadvancedhome.listeners.GUIListener;
import me.db.dbadvancedhome.listeners.MoveListener;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import me.db.dbadvancedhome.commands.HomeCommand;
import me.db.dbadvancedhome.commands.DelHomeCommand;
import me.db.dbadvancedhome.commands.DBHomeCommand;
import me.db.dbadvancedhome.commands.DBReloadCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class DBAdvancedHome extends JavaPlugin {

    private static DBAdvancedHome instance;

    private HomeManager homeManager;
    private TeleportManager teleportManager;
    private GUIListener guiListener;

    @Override
    public void onEnable() {
        instance = this;

        // Create config.yml if not exists
        saveDefaultConfig();

        // Initialize managers
        homeManager = new HomeManager(this);
        teleportManager = new TeleportManager(this);

        // Initialize GUI listener ONCE
        guiListener = new GUIListener(this, homeManager, teleportManager);

        // Register commands
        getCommand("home").setExecutor(new HomeCommand(this));
        getCommand("delhome").setExecutor(new DelHomeCommand(this));
        getCommand("dbhome").setExecutor(new DBHomeCommand(this));
        getCommand("dbreload").setExecutor(new DBReloadCommand(this));

        // Register listeners
        getServer().getPluginManager().registerEvents(guiListener, this);
        getServer().getPluginManager().registerEvents(
                new MoveListener(this, teleportManager), this
        );

        getLogger().info("DBAdvancedHome has been enabled successfully.");
    }

    @Override
    public void onDisable() {
        getLogger().info("DBAdvancedHome has been disabled.");
    }

    // ------------------------------------------------
    // Getters
    // ------------------------------------------------

    public static DBAdvancedHome getInstance() {
        return instance;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }

    public TeleportManager getTeleportManager() {
        return teleportManager;
    }

    public GUIListener getGUIListener() {
        return guiListener;
    }
}