package me.db.dbadvancedhome;

import me.db.dbadvancedhome.commands.DBHomeCommand;
import me.db.dbadvancedhome.commands.DBReloadCommand;
import me.db.dbadvancedhome.commands.DelHomeCommand;
import me.db.dbadvancedhome.commands.HomeCommand;
import me.db.dbadvancedhome.listeners.ChatConfirmListener;
import me.db.dbadvancedhome.listeners.GUIListener;
import me.db.dbadvancedhome.listeners.MoveListener;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.plugin.java.JavaPlugin;

public class DBAdvancedHome extends JavaPlugin {

    private static DBAdvancedHome instance;

    private HomeManager homeManager;
    private TeleportManager teleportManager;
    private GUIListener guiListener;
    private ChatConfirmListener chatConfirmListener;

    @Override
    public void onEnable() {
        instance = this;

        try {
            saveDefaultConfig();

            /* ================= MANAGERS ================= */
            homeManager = new HomeManager(this);
            teleportManager = new TeleportManager(this);

            /* ================= CHAT CONFIRM LISTENER ================= */
            chatConfirmListener = new ChatConfirmListener(this, homeManager);

            /* ================= GUI LISTENER ================= */
            guiListener = new GUIListener(
                    this,
                    homeManager,
                    teleportManager,
                    chatConfirmListener
            );

            /* ================= REGISTER LISTENERS ================= */
            getServer().getPluginManager().registerEvents(guiListener, this);
            getServer().getPluginManager().registerEvents(
                    new MoveListener(this, teleportManager),
                    this
            );

            /* ================= REGISTER INTERNAL COMMANDS ================= */
            if (getCommand("dbhome_confirm_yes") != null)
                getCommand("dbhome_confirm_yes").setExecutor(chatConfirmListener);

            if (getCommand("dbhome_confirm_no") != null)
                getCommand("dbhome_confirm_no").setExecutor(chatConfirmListener);

            /* ================= USER COMMANDS ================= */
            if (getCommand("home") != null)
                getCommand("home").setExecutor(new HomeCommand(this));

            if (getCommand("delhome") != null)
                getCommand("delhome").setExecutor(new DelHomeCommand(this));

            if (getCommand("dbhome") != null)
                getCommand("dbhome").setExecutor(new DBHomeCommand(this));

            if (getCommand("dbreload") != null)
                getCommand("dbreload").setExecutor(new DBReloadCommand(this));

            getLogger().info("DBAdvancedHome enabled successfully.");

        } catch (Exception e) {
            logError("Failed to enable DBAdvancedHome!", e);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        getLogger().info("DBAdvancedHome disabled.");
        instance = null;
    }

    /* ================= ERROR LOGGER ================= */
    public void logError(String message, Exception e) {
        getLogger().severe("====================================");
        getLogger().severe(message);
        if (e != null) e.printStackTrace();
        getLogger().severe("====================================");
    }

    /* ================= GETTERS ================= */
    public static DBAdvancedHome getInstance() {
        return instance;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }

    public TeleportManager getTeleportManager() {
        return teleportManager;
    }

    public GUIListener getGUIListener() {
        return guiListener;
    }

    public ChatConfirmListener getChatConfirmListener() {
        return chatConfirmListener;
    }
}