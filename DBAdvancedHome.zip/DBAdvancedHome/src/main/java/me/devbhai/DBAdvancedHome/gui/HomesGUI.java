package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.HomeManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class HomesGUI {

    // Bed slots
    private static final int[] HOME_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            28, 29, 30, 31, 32, 33, 34
    };

    // Unset dye slots
    private static final int[] UNSET_SLOTS = {
            19, 20, 21, 22, 23, 24, 25,
            37, 38, 39, 40, 41, 42, 43
    };

    public static void open(Player player, DBAdvancedHome plugin) {

        ConfigurationSection gui = plugin.getConfig().getConfigurationSection("gui");
        if (gui == null) return;

        ConfigurationSection items = gui.getConfigurationSection("items");
        if (items == null) return;

        ConfigurationSection filler = gui.getConfigurationSection("filler");
        if (filler == null) return;

        int rows = gui.getInt("rows", 6);
        String title = color(gui.getString("title", "Homes"));

        // ✅ IMPORTANT: USE HOLDER (THIS FIXES ITEM MOVEMENT)
        Inventory inv = Bukkit.createInventory(
                new HomesHolder(),
                rows * 9,
                title
        );

        /* ---------------- FILLER ---------------- */
        ItemStack fillerItem = new ItemStack(
                Material.valueOf(filler.getString("material"))
        );
        ItemMeta fm = fillerItem.getItemMeta();
        fm.setDisplayName(color(filler.getString("name")));
        fillerItem.setItemMeta(fm);

        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, fillerItem);
        }

        /* ---------------- HOMES ---------------- */
        HomeManager homeManager = plugin.getHomeManager();
        UUID uuid = player.getUniqueId();
        int defaultHomes = plugin.getConfig().getInt("default-homes", 2);

        for (int i = 0; i < HOME_SLOTS.length; i++) {

            int homeNumber = i + 1;
            int bedSlot = HOME_SLOTS[i];
            int dyeSlot = UNSET_SLOTS[i];

            // ❌ No permission
            if (homeNumber > defaultHomes &&
                    !player.hasPermission("dbadvancedhome.homes." + homeNumber)) {

                inv.setItem(
                        bedSlot,
                        buildItem(items.getConfigurationSection("home-no-permission"), homeNumber)
                );
                continue;
            }

            // 🟣 Home exists
            if (homeManager.hasHome(uuid, homeNumber)) {

                inv.setItem(
                        bedSlot,
                        buildItem(items.getConfigurationSection("home-set"), homeNumber)
                );

                inv.setItem(
                        dyeSlot,
                        buildItem(items.getConfigurationSection("home-unset"), homeNumber)
                );
                continue;
            }

            // ⚪ Not set
            inv.setItem(
                    bedSlot,
                    buildItem(items.getConfigurationSection("home-not-set"), homeNumber)
            );
        }

        player.openInventory(inv);
        playSound(player, plugin, "gui-open");
    }

    /* ---------------- ITEM BUILDER ---------------- */

    private static ItemStack buildItem(ConfigurationSection section, int number) {

        if (section == null) return new ItemStack(Material.BARRIER);

        Material material = Material.valueOf(section.getString("material"));
        String name = section.getString("name");
        List<String> lore = section.getStringList("lore");

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(
                color(name.replace("%number%", String.valueOf(number)))
        );

        if (lore != null && !lore.isEmpty()) {
            meta.setLore(
                    lore.stream()
                            .map(s -> color(s.replace("%number%", String.valueOf(number))))
                            .collect(Collectors.toList())
            );
        }

        item.setItemMeta(meta);
        return item;
    }

    /* ---------------- SOUND ---------------- */

    private static void playSound(Player player, DBAdvancedHome plugin, String key) {
        String soundName = plugin.getConfig().getString("sounds." + key);
        if (soundName == null) return;

        try {
            player.playSound(
                    player.getLocation(),
                    Sound.valueOf(soundName),
                    1f,
                    1f
            );
        } catch (Exception ignored) {}
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}