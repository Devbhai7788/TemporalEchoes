package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.HomeManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class HomesGUI {

    public static void open(Player player, DBAdvancedHome plugin) {

        int rows = plugin.getConfig().getInt("gui.rows");
        String title = color(plugin.getConfig().getString("gui.title"));

        Inventory inv = Bukkit.createInventory(null, rows * 9, title);

        HomeManager homeManager = plugin.getHomeManager();

        int maxHomes = plugin.getConfig().getInt("max-home-limit");

        for (int i = 1; i <= maxHomes; i++) {

            ItemStack item;
            ItemMeta meta;

            boolean hasHome = homeManager.hasHome(player.getUniqueId(), i);

            if (hasHome) {
                ConfigurationSection sec = plugin.getConfig().getConfigurationSection("gui.items.home-set");
                item = new ItemStack(Material.valueOf(sec.getString("material")));
                meta = item.getItemMeta();

                meta.setDisplayName(color(
                        sec.getString("name").replace("%number%", String.valueOf(i))
                ));
                meta.setLore(colorList(sec.getStringList("lore")));
            } else {
                ConfigurationSection sec = plugin.getConfig().getConfigurationSection("gui.items.home-not-set");
                item = new ItemStack(Material.valueOf(sec.getString("material")));
                meta = item.getItemMeta();

                meta.setDisplayName(color(sec.getString("name")));
                meta.setLore(colorList(sec.getStringList("lore")));
            }

            item.setItemMeta(meta);
            inv.setItem(i - 1, item);
        }

        player.openInventory(inv);
    }

    /* ---------------- utils ---------------- */

    private static String color(String s) {
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', s);
    }

    private static List<String> colorList(List<String> list) {
        return list.stream().map(HomesGUI::color).toList();
    }
}