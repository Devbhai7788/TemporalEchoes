package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.HomeManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class HomesGUI {

    // Bed slots
    private static final int[] HOME_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            28, 29, 30, 31, 32, 33, 34
    };

    // Dye slots (directly below beds)
    private static final int[] UNSET_SLOTS = {
            19, 20, 21, 22, 23, 24, 25,
            37, 38, 39, 40, 41, 42, 43
    };

    public static void open(Player player, DBAdvancedHome plugin) {

        ConfigurationSection gui = plugin.getConfig().getConfigurationSection("gui");
        ConfigurationSection items = gui.getConfigurationSection("items");

        int rows = gui.getInt("rows", 6);
        String title = color(gui.getString("title"));

        Inventory inv = Bukkit.createInventory(null, rows * 9, title);

        /* -------- filler -------- */
        ConfigurationSection filler = gui.getConfigurationSection("filler");
        ItemStack fillerItem = new ItemStack(Material.valueOf(filler.getString("material")));
        ItemMeta fm = fillerItem.getItemMeta();
        fm.setDisplayName(color(filler.getString("name")));
        fillerItem.setItemMeta(fm);

        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, fillerItem);
        }

        /* -------- homes -------- */
        HomeManager homeManager = plugin.getHomeManager();
        UUID uuid = player.getUniqueId();
        int defaultHomes = plugin.getConfig().getInt("default-homes", 2);

        for (int i = 0; i < HOME_SLOTS.length; i++) {

            int homeNumber = i + 1;
            int bedSlot = HOME_SLOTS[i];
            int dyeSlot = UNSET_SLOTS[i];

            // ❌ no permission
            if (homeNumber > defaultHomes &&
                    !player.hasPermission("dbadvancedhome.homes." + homeNumber)) {

                inv.setItem(
                        bedSlot,
                        buildItem(items.getConfigurationSection("home-no-permission"), homeNumber)
                );
                continue;
            }

            // 🟣 home set → bed + dye
            if (homeManager.hasHome(uuid, homeNumber)) {

                inv.setItem(
                        bedSlot,
                        buildItem(items.getConfigurationSection("home-set"), homeNumber)
                );

                inv.setItem(
                        dyeSlot,
                        buildItem(items.getConfigurationSection("home-unset"), homeNumber)
                );
                continue;
            }

            // ⚪ can set
            inv.setItem(
                    bedSlot,
                    buildItem(items.getConfigurationSection("home-not-set"), homeNumber)
            );
        }

        player.openInventory(inv);
    }

    /* -------- item builder -------- */
    private static ItemStack buildItem(ConfigurationSection section, int number) {

        ItemStack item = new ItemStack(Material.valueOf(section.getString("material")));
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(
                color(section.getString("name")
                        .replace("%number%", String.valueOf(number)))
        );

        List<String> lore = section.getStringList("lore");
        if (!lore.isEmpty()) {
            meta.setLore(
                    lore.stream()
                            .map(s -> color(s.replace("%number%", String.valueOf(number))))
                            .collect(Collectors.toList())
            );
        }

        item.setItemMeta(meta);
        return item;
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}