package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.gui.AdminViewGUI;
import me.db.dbadvancedhome.gui.ConfirmDeleteGUI;
import me.db.dbadvancedhome.gui.HomesGUI;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {

    private final DBAdvancedHome plugin;
    private final HomeManager homeManager;
    private final TeleportManager teleportManager;

    private final Map<UUID, UUID> adminTargets = new HashMap<>();

    // Beds
    private static final int[] HOME_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            28, 29, 30, 31, 32, 33, 34
    };

    // Dyes
    private static final int[] UNSET_SLOTS = {
            19, 20, 21, 22, 23, 24, 25,
            37, 38, 39, 40, 41, 42, 43
    };

    public GUIListener(DBAdvancedHome plugin,
                       HomeManager homeManager,
                       TeleportManager teleportManager) {
        this.plugin = plugin;
        this.homeManager = homeManager;
        this.teleportManager = teleportManager;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null) return;

        // 🔒 ONLY TOP INVENTORY
        if (event.getRawSlot() >= event.getView().getTopInventory().getSize()) {
            return;
        }

        String title = ChatColor.stripColor(event.getView().getTitle());
        event.setCancelled(true);

        // Player homes GUI
        if (title.equals(ChatColor.stripColor(plugin.getConfig().getString("gui.title")))) {
            handlePlayerClick(player, event.getRawSlot());
            return;
        }

        // Admin homes GUI
        if (title.endsWith("'s Homes")) {
            handleAdminClick(player, event.getRawSlot());
            return;
        }

        // Confirm unset GUI
        if (title.startsWith("Unset Home")) {
            handleConfirmUnset(player, event.getRawSlot());
        }
    }

    /* ---------------- PLAYER GUI ---------------- */

    private void handlePlayerClick(Player player, int slot) {

    UUID uuid = player.getUniqueId();

    for (int i = 0; i < HOME_SLOTS.length; i++) {
        if (HOME_SLOTS[i] != slot) continue;

        int homeNumber = i + 1;

        // 🔒 PERMISSION CHECK
        if (homeNumber > plugin.getConfig().getInt("default-homes")
                && !player.hasPermission("dbadvancedhome.homes." + homeNumber)) {

            player.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.no-permission")
            ));
            return;
        }

        // 🟣 HOME EXISTS → TELEPORT
        if (homeManager.hasHome(uuid, homeNumber)) {

            Location loc = homeManager.getHome(uuid, homeNumber);
            if (loc == null) {
                player.sendMessage(color("&cHome location is invalid."));
                return;
            }

            teleportManager.startTeleport(player, loc, "Home " + homeNumber);
            return;
        }

        // ⚪ SET HOME
        homeManager.setHome(uuid, homeNumber, player.getLocation());

        player.sendMessage(color(
                plugin.getConfig().getString("prefix")
                        + plugin.getConfig().getString("messages.home-set")
        ));

        HomesGUI.open(player, plugin);
        return;
    }

    // 🟢 DYE → CONFIRM UNSET
    for (int i = 0; i < UNSET_SLOTS.length; i++) {
        if (UNSET_SLOTS[i] == slot) {
            ConfirmDeleteGUI.open(player, i + 1, plugin);
            return;
        }
    }
}
    /* ---------------- ADMIN GUI ---------------- */

    private void handleAdminClick(Player admin, int slot) {

        UUID targetUUID = adminTargets.get(admin.getUniqueId());
        if (targetUUID == null) return;

        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] == slot && homeManager.hasHome(targetUUID, i + 1)) {

                Location loc = homeManager.getHome(targetUUID, i + 1);
                OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);

                teleportManager.startTeleport(
                        admin,
                        loc,
                        target.getName() + "'s Home " + (i + 1)
                );
                return;
            }
        }
    }

    /* ---------------- CONFIRM GUI ---------------- */

    private void handleConfirmUnset(Player player, int slot) {

        if (!player.hasMetadata("confirm_unset_home")) return;

        int homeNumber = player.getMetadata("confirm_unset_home").get(0).asInt();

        if (slot == 11) { // YES
            homeManager.deleteHome(player.getUniqueId(), homeNumber);
            player.removeMetadata("confirm_unset_home", plugin);
            HomesGUI.open(player, plugin);
        }

        if (slot == 15) { // NO
            player.removeMetadata("confirm_unset_home", plugin);
            HomesGUI.open(player, plugin);
        }
    }

    /* ---------------- ADMIN OPEN ---------------- */

    public void openAdminGUI(Player admin, UUID targetUUID) {
        adminTargets.put(admin.getUniqueId(), targetUUID);
        AdminViewGUI.open(admin, targetUUID, plugin);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        String title = ChatColor.stripColor(event.getView().getTitle());
        if (title.endsWith("'s Homes")) {
            adminTargets.remove(event.getPlayer().getUniqueId());
        }
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}