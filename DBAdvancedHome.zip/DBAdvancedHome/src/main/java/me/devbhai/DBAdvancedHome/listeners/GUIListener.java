package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.gui.AdminViewGUI;
import me.db.dbadvancedhome.gui.ConfirmDeleteGUI;
import me.db.dbadvancedhome.gui.HomesGUI;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {

    private final DBAdvancedHome plugin;
    private final HomeManager homeManager;
    private final TeleportManager teleportManager;

    private final Map<UUID, UUID> adminTargets = new HashMap<>();

    private static final int[] HOME_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            28, 29, 30, 31, 32, 33, 34
    };

    private static final int[] UNSET_SLOTS = {
            19, 20, 21, 22, 23, 24, 25,
            37, 38, 39, 40, 41, 42, 43
    };

    public GUIListener(DBAdvancedHome plugin,
                       HomeManager homeManager,
                       TeleportManager teleportManager) {
        this.plugin = plugin;
        this.homeManager = homeManager;
        this.teleportManager = teleportManager;
    }

    /* ================= CLICK ================= */

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {

        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = ChatColor.stripColor(event.getView().getTitle());
        String homeTitle = ChatColor.stripColor(
                plugin.getConfig().getString("gui.title", "Homes")
        );
        String confirmBase = ChatColor.stripColor(
                plugin.getConfig().getString("confirm-gui.title", "Unset Home")
        ).replace("%number%", "");

        boolean isHomeGui = title.equals(homeTitle);
        boolean isAdminGui = title.endsWith("'s Homes");
        boolean isConfirmGui = title.startsWith(confirmBase);

        if (!isHomeGui && !isAdminGui && !isConfirmGui) return;

        // 🔒 FULL BLOCK FOR GUI ONLY
        event.setCancelled(true);

        if (event.getClickedInventory() == null) return;
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;

        int slot = event.getRawSlot();
        playSound(player, "click");

        if (isHomeGui) {
            handlePlayerClick(player, slot);
            return;
        }

        if (isAdminGui) {
            handleAdminClick(player, slot);
            return;
        }

        handleConfirmUnset(player, slot);
    }

    /* ================= DRAG (CRITICAL FIX) ================= */

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {

        String title = ChatColor.stripColor(event.getView().getTitle());
        String homeTitle = ChatColor.stripColor(
                plugin.getConfig().getString("gui.title", "Homes")
        );

        if (title.equals(homeTitle)
                || title.endsWith("'s Homes")
                || title.startsWith("Unset Home")) {

            event.setCancelled(true);
        }
    }

    /* ================= PLAYER GUI ================= */

    private void handlePlayerClick(Player player, int slot) {

        UUID uuid = player.getUniqueId();

        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] != slot) continue;

            int homeNumber = i + 1;

            if (homeNumber > plugin.getConfig().getInt("default-homes")
                    && !player.hasPermission("dbadvancedhome.homes." + homeNumber)) {

                playSound(player, "no-permission");
                player.sendMessage(color(
                        plugin.getConfig().getString("prefix")
                                + plugin.getConfig().getString("messages.no-permission")
                ));
                return;
            }

            if (homeManager.hasHome(uuid, homeNumber)) {
                Location loc = homeManager.getHome(uuid, homeNumber);
                if (loc != null) {
                    teleportManager.startTeleport(player, loc, "Home " + homeNumber);
                    playSound(player, "teleport");
                }
                return;
            }

            homeManager.setHome(uuid, homeNumber, player.getLocation());
            playSound(player, "home-set");

            player.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.home-set")
            ));

            HomesGUI.open(player, plugin);
            return;
        }

        for (int i = 0; i < UNSET_SLOTS.length; i++) {
            if (UNSET_SLOTS[i] == slot) {
                player.setMetadata(
                        "confirm_unset_home",
                        new FixedMetadataValue(plugin, i + 1)
                );
                ConfirmDeleteGUI.open(player, i + 1, plugin);
                return;
            }
        }
    }

    /* ================= ADMIN GUI ================= */

    private void handleAdminClick(Player admin, int slot) {

        UUID targetUUID = adminTargets.get(admin.getUniqueId());
        if (targetUUID == null) return;

        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] != slot) continue;

            int homeNumber = i + 1;
            if (!homeManager.hasHome(targetUUID, homeNumber)) return;

            Location loc = homeManager.getHome(targetUUID, homeNumber);
            OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);

            teleportManager.startTeleport(
                    admin,
                    loc,
                    target.getName() + "'s Home " + homeNumber
            );
            playSound(admin, "teleport");
            return;
        }
    }

    /* ================= CONFIRM ================= */

    private void handleConfirmUnset(Player player, int slot) {

        if (!player.hasMetadata("confirm_unset_home")) return;

        int homeNumber = player.getMetadata("confirm_unset_home").get(0).asInt();

        if (slot == 11) {
            homeManager.deleteHome(player.getUniqueId(), homeNumber);
            playSound(player, "unset-confirm");
            player.removeMetadata("confirm_unset_home", plugin);
            HomesGUI.open(player, plugin);
        }

        if (slot == 15) {
            playSound(player, "unset-cancel");
            player.removeMetadata("confirm_unset_home", plugin);
            HomesGUI.open(player, plugin);
        }
    }

    /* ================= ADMIN OPEN ================= */

    public void openAdminGUI(Player admin, UUID targetUUID) {
        adminTargets.put(admin.getUniqueId(), targetUUID);
        AdminViewGUI.open(admin, targetUUID, plugin);
    }

    /* ================= CLOSE ================= */

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {

        String title = ChatColor.stripColor(event.getView().getTitle());
        String homeTitle = ChatColor.stripColor(
                plugin.getConfig().getString("gui.title", "Homes")
        );

        if (!title.equals(homeTitle)
                && !title.endsWith("'s Homes")
                && !title.startsWith("Unset Home")) {
            return;
        }

        if (event.getPlayer() instanceof Player player) {
            playSound(player, "gui-close");
        }

        adminTargets.remove(event.getPlayer().getUniqueId());
    }

    /* ================= UTIL ================= */

    private void playSound(Player player, String key) {
        String soundName = plugin.getConfig().getString("sounds." + key);
        if (soundName == null) return;

        try {
            player.playSound(player.getLocation(), Sound.valueOf(soundName), 1f, 1f);
        } catch (Exception ignored) {}
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}