package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.gui.*;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {

    private final DBAdvancedHome plugin;
    private final HomeManager homeManager;
    private final TeleportManager teleportManager;

    private final Map<UUID, UUID> adminTargets = new HashMap<>();

    private static final int[] HOME_SLOTS = {
            10,11,12,13,14,15,16,
            28,29,30,31,32,33,34
    };

    private static final int[] UNSET_SLOTS = {
            19,20,21,22,23,24,25,
            37,38,39,40,41,42,43
    };

    public GUIListener(DBAdvancedHome plugin,
                       HomeManager homeManager,
                       TeleportManager teleportManager) {
        this.plugin = plugin;
        this.homeManager = homeManager;
        this.teleportManager = teleportManager;
    }

    /* =====================================================
     * DRAG — BLOCK ONLY OUR GUIs
     * ===================================================== */
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof HomesHolder
                || event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder
                || event.getView().getTopInventory().getHolder() instanceof ConfirmHolder) {
            event.setCancelled(true);
        }
    }

    /* =====================================================
     * CLICK — ONLY OUR GUIs
     * ===================================================== */
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {

        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (!(event.getView().getTopInventory().getHolder() instanceof HomesHolder
                || event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder
                || event.getView().getTopInventory().getHolder() instanceof ConfirmHolder)) {
            return;
        }

        event.setCancelled(true);

        if (event.getClickedInventory() == null) return;
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;

        int slot = event.getRawSlot();
        playSound(player, "click");

        if (event.getView().getTopInventory().getHolder() instanceof HomesHolder) {
            handlePlayerClick(player, slot, event);
            return;
        }

        if (event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder) {
            handleAdminClick(player, slot);
            return;
        }

        handleConfirmUnset(player, slot);
    }

    /* =====================================================
     * PLAYER GUI
     * ===================================================== */
    private void handlePlayerClick(Player player, int slot, InventoryClickEvent event) {

        UUID uuid = player.getUniqueId();

        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] != slot) continue;

            int homeNumber = i + 1;

            if (homeNumber > plugin.getConfig().getInt("default-homes")
                    && !player.hasPermission("dbadvancedhome.homes." + homeNumber)) {
                playSound(player, "no-permission");
                return;
            }

            if (homeManager.hasHome(uuid, homeNumber)) {
                Location loc = homeManager.getHome(uuid, homeNumber);
                if (loc == null) return;

                player.closeInventory();
                teleportManager.startTeleport(player, loc, "Home " + homeNumber);
                playSound(player, "teleport");
                return;
            }

            homeManager.setHome(uuid, homeNumber, player.getLocation());
            playSound(player, "home-set");
            HomesGUI.open(player, plugin);
            return;
        }

        for (int i = 0; i < UNSET_SLOTS.length; i++) {
            if (UNSET_SLOTS[i] != slot) continue;

            int homeNumber = i + 1;

            if (!homeManager.hasHome(uuid, homeNumber)) return;

            if (event.getCurrentItem() == null
                    || event.getCurrentItem().getType() == Material.AIR) return;

            ConfirmDeleteGUI.open(player, homeNumber, plugin);
            return;
        }
    }

    /* =====================================================
     * ADMIN GUI
     * ===================================================== */
    private void handleAdminClick(Player admin, int slot) {

        UUID targetUUID = adminTargets.get(admin.getUniqueId());
        if (targetUUID == null) return;

        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] != slot) continue;

            Location loc = homeManager.getHome(targetUUID, i + 1);
            OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);

            admin.closeInventory();
            teleportManager.startTeleport(
                    admin,
                    loc,
                    target.getName() + "'s Home " + (i + 1)
            );
            playSound(admin, "teleport");
            return;
        }
    }

    /* =====================================================
     * CONFIRM GUI
     * ===================================================== */
    private void handleConfirmUnset(Player player, int slot) {

        if (!player.hasMetadata("confirm_unset_home")) return;

        int homeNumber = player.getMetadata("confirm_unset_home").get(0).asInt();

        int yesSlot = plugin.getConfig().getInt("confirm-gui.yes.slot", 11);
        int noSlot  = plugin.getConfig().getInt("confirm-gui.no.slot", 15);

        if (slot == yesSlot) {
            player.closeInventory();
            homeManager.deleteHome(player.getUniqueId(), homeNumber);
            playSound(player, "unset-confirm");
            player.removeMetadata("confirm_unset_home", plugin);
            HomesGUI.open(player, plugin);
            return;
        }

        if (slot == noSlot) {
            player.closeInventory();
            playSound(player, "unset-cancel");
            player.removeMetadata("confirm_unset_home", plugin);
            HomesGUI.open(player, plugin);
        }
    }

    /* =====================================================
     * ADMIN OPEN
     * ===================================================== */
    public void openAdminGUI(Player admin, UUID targetUUID) {
        adminTargets.put(admin.getUniqueId(), targetUUID);
        AdminViewGUI.open(admin, targetUUID, plugin);
    }

    /* =====================================================
     * CLOSE
     * ===================================================== */
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof HomesHolder
                || event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder
                || event.getView().getTopInventory().getHolder() instanceof ConfirmHolder)) {
            return;
        }

        if (event.getPlayer() instanceof Player player) {
            playSound(player, "gui-close");
        }

        adminTargets.remove(event.getPlayer().getUniqueId());
    }

    /* =====================================================
     * UTIL
     * ===================================================== */
    private void playSound(Player player, String key) {
        String sound = plugin.getConfig().getString("sounds." + key);
        if (sound == null) return;
        try {
            player.playSound(player.getLocation(), Sound.valueOf(sound), 1f, 1f);
        } catch (Exception ignored) {}
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}