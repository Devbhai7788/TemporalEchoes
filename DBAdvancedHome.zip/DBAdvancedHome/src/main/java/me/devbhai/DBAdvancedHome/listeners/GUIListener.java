package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.gui.AdminViewGUI;
import me.db.dbadvancedhome.gui.HomesGUI;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {

    private final DBAdvancedHome plugin;
    private final HomeManager homeManager;
    private final TeleportManager teleportManager;

    // Track admin GUI target
    private final Map<UUID, UUID> adminViewTargets = new HashMap<>();

    public GUIListener(DBAdvancedHome plugin,
                       HomeManager homeManager,
                       TeleportManager teleportManager) {
        this.plugin = plugin;
        this.homeManager = homeManager;
        this.teleportManager = teleportManager;
    }

    /* --------------------------------------------------
     * Inventory Click
     * -------------------------------------------------- */
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null) return;

        Inventory inv = event.getView().getTopInventory();
        String title = ChatColor.stripColor(event.getView().getTitle());

        // Player Homes GUI
        if (title.equals(ChatColor.stripColor(
                plugin.getConfig().getString("gui.title")))) {

            event.setCancelled(true);
            handlePlayerHomesClick(player, event.getSlot(), event.getCurrentItem());
            return;
        }

        // Admin View GUI
        if (title.endsWith("'s Homes")) {

            event.setCancelled(true);
            handleAdminHomesClick(player, event.getSlot());
        }
    }

    /* --------------------------------------------------
     * Player GUI Clicks
     * -------------------------------------------------- */
    private void handlePlayerHomesClick(Player player, int slot, ItemStack item) {

        if (item == null || !item.hasItemMeta()) return;

        int homeNumber = slot + 1;

        // Has home → teleport
        if (homeManager.hasHome(player.getUniqueId(), homeNumber)) {

            Location loc = homeManager.getHome(player.getUniqueId(), homeNumber);
            teleportManager.startTeleport(
                    player,
                    loc,
                    "Home " + homeNumber
            );
            return;
        }

        // No home → set home
        int maxHomes = plugin.getConfig().getInt("max-home-limit");
        if (homeNumber > maxHomes) return;

        homeManager.setHome(player.getUniqueId(), homeNumber, player.getLocation());

        player.sendMessage(color(
                plugin.getConfig().getString("prefix")
                        + plugin.getConfig().getString("messages.home-set")
        ));

        // Refresh GUI
        HomesGUI.open(player, plugin);
    }

    /* --------------------------------------------------
     * Admin GUI Clicks
     * -------------------------------------------------- */
    private void handleAdminHomesClick(Player admin, int slot) {

        UUID targetUUID = adminViewTargets.get(admin.getUniqueId());
        if (targetUUID == null) return;

        int homeNumber = slot + 1;

        if (!homeManager.hasHome(targetUUID, homeNumber)) return;

        Location loc = homeManager.getHome(targetUUID, homeNumber);

        OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);

        teleportManager.startTeleport(
                admin,
                loc,
                target.getName() + "'s Home " + homeNumber
        );
    }

    /* --------------------------------------------------
     * Track admin GUI target
     * -------------------------------------------------- */
    public void openAdminGUI(Player admin, UUID targetUUID) {
        adminViewTargets.put(admin.getUniqueId(), targetUUID);
        AdminViewGUI.open(admin, targetUUID, plugin);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        adminViewTargets.remove(event.getPlayer().getUniqueId());
    }

    /* --------------------------------------------------
     * Utils
     * -------------------------------------------------- */
    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}