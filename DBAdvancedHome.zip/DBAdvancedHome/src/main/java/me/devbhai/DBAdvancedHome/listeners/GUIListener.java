package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.gui.AdminHomesHolder;
import me.db.dbadvancedhome.gui.AdminViewGUI;
import me.db.dbadvancedhome.gui.HomesGUI;
import me.db.dbadvancedhome.gui.HomesHolder;
import me.db.dbadvancedhome.managers.HomeManager;
import me.db.dbadvancedhome.managers.TeleportManager;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {

    private final DBAdvancedHome plugin;
    private final HomeManager homeManager;
    private final TeleportManager teleportManager;

    private final Map<UUID, UUID> adminTargets = new HashMap<>();

    // 🔑 pending delete (player → homeNumber)
    public final Map<UUID, Integer> pendingDelete = new HashMap<>();

    private static final int[] HOME_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            28, 29, 30, 31, 32, 33, 34
    };

    private static final int[] UNSET_SLOTS = {
            19, 20, 21, 22, 23, 24, 25,
            37, 38, 39, 40, 41, 42, 43
    };

    public GUIListener(DBAdvancedHome plugin,
                       HomeManager homeManager,
                       TeleportManager teleportManager) {
        this.plugin = plugin;
        this.homeManager = homeManager;
        this.teleportManager = teleportManager;
    }

    /* ================= DRAG ================= */
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof HomesHolder
                || event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder) {
            event.setCancelled(true);
        }
    }

    /* ================= CLICK ================= */
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {

        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (!(event.getView().getTopInventory().getHolder() instanceof HomesHolder
                || event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder)) {
            return;
        }

        event.setCancelled(true);

        if (event.getClickedInventory() == null) return;
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;

        int slot = event.getRawSlot();
        playSound(player, "click");

        if (event.getView().getTopInventory().getHolder() instanceof HomesHolder) {
            handlePlayerClick(player, slot, event);
            return;
        }

        if (event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder) {
            handleAdminClick(player, slot);
        }
    }

    /* ================= PLAYER GUI ================= */
    private void handlePlayerClick(Player player, int slot, InventoryClickEvent event) {

        UUID uuid = player.getUniqueId();

        // BED → SET / TELEPORT
        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] != slot) continue;

            int homeNumber = i + 1;

            if (homeNumber > plugin.getConfig().getInt("default-homes")
                    && !player.hasPermission("dbadvancedhome.homes." + homeNumber)) {
                playSound(player, "no-permission");
                return;
            }

            if (homeManager.hasHome(uuid, homeNumber)) {
                Location loc = homeManager.getHome(uuid, homeNumber);
                if (loc == null) return;

                player.closeInventory();
                teleportManager.startTeleport(player, loc, "Home " + homeNumber);
                playSound(player, "teleport");
                return;
            }

            homeManager.setHome(uuid, homeNumber, player.getLocation());
            playSound(player, "home-set");
            HomesGUI.open(player, plugin);
            return;
        }

        // LIME_DYE → CHAT CONFIRM
        for (int i = 0; i < UNSET_SLOTS.length; i++) {
            if (UNSET_SLOTS[i] != slot) continue;

            int homeNumber = i + 1;

            if (!homeManager.hasHome(uuid, homeNumber)) return;

            if (event.getCurrentItem() == null
                    || event.getCurrentItem().getType() != Material.LIME_DYE) return;

            player.closeInventory();
            pendingDelete.put(uuid, homeNumber);

            // Question
            player.sendMessage(color(
                    plugin.getConfig().getString("chat-confirm.question")
                            .replace("%number%", String.valueOf(homeNumber))
            ));

            // YES button
            TextComponent yes = new TextComponent(
                    color(plugin.getConfig().getString("chat-confirm.yes"))
            );
            yes.setClickEvent(new ClickEvent(
                    ClickEvent.Action.RUN_COMMAND,
                    "/dbhome_confirm_yes"
            ));

            // NO button
            TextComponent no = new TextComponent(
                    color(plugin.getConfig().getString("chat-confirm.no"))
            );
            no.setClickEvent(new ClickEvent(
                    ClickEvent.Action.RUN_COMMAND,
                    "/dbhome_confirm_no"
            ));

            TextComponent space = new TextComponent(" ");

            player.spigot().sendMessage(yes, space, no);
            return;
        }
    }

    /* ================= ADMIN GUI ================= */
    private void handleAdminClick(Player admin, int slot) {

        UUID targetUUID = adminTargets.get(admin.getUniqueId());
        if (targetUUID == null) return;

        for (int i = 0; i < HOME_SLOTS.length; i++) {
            if (HOME_SLOTS[i] != slot) continue;

            Location loc = homeManager.getHome(targetUUID, i + 1);
            OfflinePlayer target = Bukkit.getOfflinePlayer(targetUUID);

            admin.closeInventory();
            teleportManager.startTeleport(
                    admin,
                    loc,
                    target.getName() + "'s Home " + (i + 1)
            );
            playSound(admin, "teleport");
            return;
        }
    }

    /* ================= ADMIN OPEN ================= */
    public void openAdminGUI(Player admin, UUID targetUUID) {
        adminTargets.put(admin.getUniqueId(), targetUUID);
        AdminViewGUI.open(admin, targetUUID, plugin);
    }

    /* ================= CLOSE ================= */
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof HomesHolder
                || event.getView().getTopInventory().getHolder() instanceof AdminHomesHolder) {
            playSound((Player) event.getPlayer(), "gui-close");
        }
    }

    /* ================= UTIL ================= */
    private void playSound(Player player, String key) {
        String sound = plugin.getConfig().getString("sounds." + key);
        if (sound == null) return;
        try {
            player.playSound(player.getLocation(), Sound.valueOf(sound), 1f, 1f);
        } catch (Exception ignored) {}
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}