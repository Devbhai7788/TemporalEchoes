package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

public class ConfirmDeleteGUI {

    public static void open(Player player, int homeNumber, DBAdvancedHome plugin) {

        Inventory inv = Bukkit.createInventory(
                null,
                27,
                color("&cUnset Home " + homeNumber + "?")
        );

        // YES BUTTON
        ItemStack yes = new ItemStack(Material.GREEN_WOOL);
        ItemMeta ym = yes.getItemMeta();
        ym.setDisplayName(color("&a&lYES"));
        ym.setLore(java.util.List.of(color("&7This will remove your home")));
        yes.setItemMeta(ym);

        // NO BUTTON
        ItemStack no = new ItemStack(Material.RED_WOOL);
        ItemMeta nm = no.getItemMeta();
        nm.setDisplayName(color("&c&lNO"));
        nm.setLore(java.util.List.of(color("&7Go back without deleting")));
        no.setItemMeta(nm);

        // FILLER
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName(" ");
        filler.setItemMeta(fm);

        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, filler);
        }

        inv.setItem(11, yes);
        inv.setItem(15, no);

        // 🔑 STORE HOME NUMBER (IMPORTANT)
        player.setMetadata(
                "confirm_unset_home",
                new FixedMetadataValue(plugin, homeNumber)
        );

        player.openInventory(inv);
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}