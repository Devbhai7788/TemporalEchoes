package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.List;
import java.util.stream.Collectors;

public class ConfirmDeleteGUI {

    public static void open(Player player, int homeNumber, DBAdvancedHome plugin) {

        ConfigurationSection gui = plugin.getConfig().getConfigurationSection("confirm-gui");
        if (gui == null) return;

        int size = gui.getInt("size", 27);

        String title = color(
                gui.getString("title", "&cUnset Home %number%")
                        .replace("%number%", String.valueOf(homeNumber))
        );

        Inventory inv = Bukkit.createInventory(null, size, title);

        /* ---------------- FILLER ---------------- */
        ConfigurationSection filler = gui.getConfigurationSection("filler");
        if (filler != null) {
            ItemStack fillerItem = new ItemStack(
                    Material.valueOf(filler.getString("material"))
            );
            ItemMeta fm = fillerItem.getItemMeta();
            fm.setDisplayName(color(filler.getString("name")));
            fillerItem.setItemMeta(fm);

            for (int i = 0; i < inv.getSize(); i++) {
                inv.setItem(i, fillerItem);
            }
        }

        /* ---------------- YES BUTTON ---------------- */
        ConfigurationSection yesSec = gui.getConfigurationSection("yes");
        if (yesSec != null) {
            ItemStack yes = buildItem(yesSec, homeNumber);
            inv.setItem(yesSec.getInt("slot"), yes);
        }

        /* ---------------- NO BUTTON ---------------- */
        ConfigurationSection noSec = gui.getConfigurationSection("no");
        if (noSec != null) {
            ItemStack no = buildItem(noSec, homeNumber);
            inv.setItem(noSec.getInt("slot"), no);
        }

        // 🔑 STORE HOME NUMBER (USED BY LISTENER)
        player.setMetadata(
                "confirm_unset_home",
                new FixedMetadataValue(plugin, homeNumber)
        );

        player.openInventory(inv);
    }

    /* ---------------- ITEM BUILDER ---------------- */

    private static ItemStack buildItem(ConfigurationSection sec, int homeNumber) {

        ItemStack item = new ItemStack(
                Material.valueOf(sec.getString("material"))
        );
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(
                color(sec.getString("name")
                        .replace("%number%", String.valueOf(homeNumber)))
        );

        List<String> lore = sec.getStringList("lore");
        if (lore != null && !lore.isEmpty()) {
            meta.setLore(
                    lore.stream()
                            .map(s -> color(s.replace("%number%", String.valueOf(homeNumber))))
                            .collect(Collectors.toList())
            );
        }

        item.setItemMeta(meta);
        return item;
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}