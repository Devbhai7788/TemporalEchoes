package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.List;

public class ConfirmDeleteGUI {

    public static void open(Player player, int homeNumber, DBAdvancedHome plugin) {

        ConfigurationSection gui = plugin.getConfig().getConfigurationSection("confirm-gui");
        if (gui == null) return;

        int size = gui.getInt("size", 27);

        String title = ChatColor.translateAlternateColorCodes('&',
                gui.getString("title", "&cUnset Home %number%")
                        .replace("%number%", String.valueOf(homeNumber))
        );

        Inventory inv = Bukkit.createInventory(
                new ConfirmHolder(),
                size,
                title
        );

        // ===== YES =====
        ConfigurationSection yes = gui.getConfigurationSection("yes");
        if (yes != null) {
            inv.setItem(
                    yes.getInt("slot", 11),
                    safeItem(yes, homeNumber)
            );
        }

        // ===== NO =====
        ConfigurationSection no = gui.getConfigurationSection("no");
        if (no != null) {
            inv.setItem(
                    no.getInt("slot", 15),
                    safeItem(no, homeNumber)
            );
        }

        player.setMetadata(
                "confirm_unset_home",
                new FixedMetadataValue(plugin, homeNumber)
        );

        player.openInventory(inv);
    }

    // ===== SAFE ITEM BUILDER =====
    private static ItemStack safeItem(ConfigurationSection sec, int number) {

        Material mat;
        try {
            mat = Material.valueOf(sec.getString("material"));
        } catch (Exception e) {
            // 🔥 FALLBACK (THIS FIXES YOUR ISSUE)
            mat = Material.STONE;
        }

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
                sec.getString("name", " ")
                        .replace("%number%", String.valueOf(number))
        ));

        List<String> lore = sec.getStringList("lore");
        if (lore != null && !lore.isEmpty()) {
            meta.setLore(
                    lore.stream()
                            .map(s -> ChatColor.translateAlternateColorCodes('&',
                                    s.replace("%number%", String.valueOf(number))))
                            .toList()
            );
        }

        item.setItemMeta(meta);
        return item;
    }
}