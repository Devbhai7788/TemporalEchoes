package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.List;
import java.util.stream.Collectors;

public class ConfirmDeleteGUI {

    public static void open(Player player, int homeNumber, DBAdvancedHome plugin) {

        ConfigurationSection gui = plugin.getConfig().getConfigurationSection("confirm-gui");
        if (gui == null) return;

        int size = gui.getInt("size", 27);

        String title = ChatColor.translateAlternateColorCodes('&',
                gui.getString("title", "&cUnset Home %number%")
                        .replace("%number%", String.valueOf(homeNumber))
        );

        Inventory inv = Bukkit.createInventory(
                new ConfirmHolder(),
                size,
                title
        );

        /* ================= YES BUTTON FIRST ================= */
        ConfigurationSection yesSec = gui.getConfigurationSection("yes");
        if (yesSec != null) {
            inv.setItem(
                    yesSec.getInt("slot"),
                    buildItem(yesSec, homeNumber)
            );
        }

        /* ================= NO BUTTON SECOND ================= */
        ConfigurationSection noSec = gui.getConfigurationSection("no");
        if (noSec != null) {
            inv.setItem(
                    noSec.getInt("slot"),
                    buildItem(noSec, homeNumber)
            );
        }

        /* ================= FILL ONLY EMPTY SLOTS ================= */
        ConfigurationSection filler = gui.getConfigurationSection("filler");
        if (filler != null) {
            ItemStack fillerItem = new ItemStack(
                    Material.valueOf(filler.getString("material"))
            );
            ItemMeta meta = fillerItem.getItemMeta();
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
                    filler.getString("name", " ")
            ));
            fillerItem.setItemMeta(meta);

            for (int i = 0; i < inv.getSize(); i++) {
                if (inv.getItem(i) == null) {
                    inv.setItem(i, fillerItem);
                }
            }
        }

        player.setMetadata(
                "confirm_unset_home",
                new FixedMetadataValue(plugin, homeNumber)
        );

        player.openInventory(inv);
    }

    private static ItemStack buildItem(ConfigurationSection sec, int homeNumber) {

        ItemStack item = new ItemStack(
                Material.valueOf(sec.getString("material"))
        );

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
                sec.getString("name")
                        .replace("%number%", String.valueOf(homeNumber))
        ));

        List<String> lore = sec.getStringList("lore");
        if (lore != null && !lore.isEmpty()) {
            meta.setLore(
                    lore.stream()
                            .map(s -> ChatColor.translateAlternateColorCodes('&',
                                    s.replace("%number%", String.valueOf(homeNumber))))
                            .collect(Collectors.toList())
            );
        }

        item.setItemMeta(meta);
        return item;
    }
}