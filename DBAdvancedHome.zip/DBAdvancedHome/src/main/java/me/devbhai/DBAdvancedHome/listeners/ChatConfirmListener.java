package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.HomeManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.Map;
import java.util.UUID;

public class ChatConfirmListener implements Listener {

    private final DBAdvancedHome plugin;
    private final HomeManager homeManager;
    private final Map<UUID, Integer> pendingDelete;

    public ChatConfirmListener(DBAdvancedHome plugin,
                               HomeManager homeManager,
                               Map<UUID, Integer> pendingDelete) {
        this.plugin = plugin;
        this.homeManager = homeManager;
        this.pendingDelete = pendingDelete;
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {

        Player player = event.getPlayer();
        String cmd = event.getMessage().toLowerCase();

        if (!cmd.equals("/dbhome_confirm_yes") && !cmd.equals("/dbhome_confirm_no")) {
            return;
        }

        event.setCancelled(true);

        Integer homeNumber = pendingDelete.remove(player.getUniqueId());
        if (homeNumber == null) return;

        if (cmd.equals("/dbhome_confirm_yes")) {
            homeManager.deleteHome(player.getUniqueId(), homeNumber);
            player.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.home-deleted")
            ));
        } else {
            player.sendMessage(ChatColor.translateAlternateColorCodes(
                    '&',
                    plugin.getConfig().getString("chat-confirm.cancelled")
            ));
        }
    }
}