package me.db.dbadvancedhome.listeners;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.managers.HomeManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;

public class ChatConfirmListener implements CommandExecutor {

    private final DBAdvancedHome plugin;
    private final HomeManager homeManager;

    // player → homeNumber
    private final Map<UUID, Integer> pendingDeletes = new HashMap<>();

    public ChatConfirmListener(DBAdvancedHome plugin, HomeManager homeManager) {
        this.plugin = plugin;
        this.homeManager = homeManager;
    }

    /* =====================================================
     * STORE REQUEST (CALLED FROM GUIListener)
     * ===================================================== */
    public void requestDelete(Player player, int homeNumber) {

    pendingDeletes.put(player.getUniqueId(), homeNumber);

    // Question message
    String question = plugin.getConfig()
            .getString("chat-confirm.question", "&cReally want to delete Home %number%?")
            .replace("%number%", String.valueOf(homeNumber));

    player.sendMessage(color(
            plugin.getConfig().getString("prefix") + question
    ));

    // YES button
    TextComponent yes = new TextComponent(
            color(plugin.getConfig().getString("chat-confirm.yes", "&a[YES]"))
    );
    yes.setClickEvent(new ClickEvent(
            ClickEvent.Action.RUN_COMMAND,
            "/dbhome_confirm_yes"
    ));

    // NO button
    TextComponent no = new TextComponent(
            color(plugin.getConfig().getString("chat-confirm.no", "&c[NO]"))
    );
    no.setClickEvent(new ClickEvent(
            ClickEvent.Action.RUN_COMMAND,
            "/dbhome_confirm_no"
    ));

    TextComponent space = new TextComponent(" ");

    player.spigot().sendMessage(yes, space, no);
}
    /* =====================================================
     * COMMAND HANDLER
     * ===================================================== */
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player player)) return true;

        UUID uuid = player.getUniqueId();

        if (!pendingDeletes.containsKey(uuid)) {
            player.sendMessage(color("&cNo delete request pending."));
            return true;
        }

        int homeNumber = pendingDeletes.remove(uuid);

        if (cmd.getName().equalsIgnoreCase("dbhome_confirm_yes")) {
            homeManager.deleteHome(uuid, homeNumber);

            player.sendMessage(color(
                    plugin.getConfig().getString("prefix")
                            + plugin.getConfig().getString("messages.home-deleted")
            ));
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("dbhome_confirm_no")) {
            player.sendMessage(color("&7Home deletion cancelled."));
            return true;
        }

        return true;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}