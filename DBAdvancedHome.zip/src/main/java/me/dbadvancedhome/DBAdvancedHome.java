
package me.dbadvancedhome;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DBAdvancedHome extends JavaPlugin implements Listener {

    private File homesFile;
    private FileConfiguration homes;
    private final Map<UUID, BukkitTask> tps = new HashMap<>();
    private final int MAX_HOMES = 12;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        loadHomes();
    }

    private void loadHomes() {
        homesFile = new File(getDataFolder(), "homes.yml");
        if (!homesFile.exists()) {
            try {
                homesFile.getParentFile().mkdirs();
                homesFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        homes = YamlConfiguration.loadConfiguration(homesFile);
    }

    private void saveHomes() {
        try { homes.save(homesFile); } catch (IOException ignored) {}
    }

    private String msg(String key) {
        return ChatColor.translateAlternateColorCodes('&',
                getConfig().getString("prefix","") + getConfig().getString("messages."+key, key));
    }

    private void play(Player p, String path) {
        try {
            p.playSound(p.getLocation(), Sound.valueOf(getConfig().getString(path)),1,1);
        } catch (Exception ignored) {}
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) return true;

        if (c.getName().equalsIgnoreCase("home")) {
            Location loc = homes.getLocation(p.getUniqueId()+".home1");
            if (loc != null) startTeleport(p, loc);
            return true;
        }

        if (c.getName().equalsIgnoreCase("homes")) {
            openGUI(p, p.getUniqueId(), false);
            return true;
        }

        if (c.getName().equalsIgnoreCase("dbhome")) {
            if (!p.hasPermission("dbadvancedhome.admin")) {
                p.sendMessage(msg("no-permission"));
                return true;
            }
            if (a.length == 1 && a[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                p.sendMessage(msg("reload-success"));
                return true;
            }
            if (a.length == 2 && a[0].equalsIgnoreCase("view")) {
                OfflinePlayer op = Bukkit.getOfflinePlayer(a[1]);
                openGUI(p, op.getUniqueId(), true);
                return true;
            }
        }
        return true;
    }

    private void startTeleport(Player p, Location loc) {
        p.sendTitle(ChatColor.GREEN+"Teleported!", "", 10,40,10);
        BukkitTask task = Bukkit.getScheduler().runTaskLater(this, () -> {
            p.teleport(loc);
            play(p,"teleport.sound");
            tps.remove(p.getUniqueId());
        }, getConfig().getInt("teleport.delay",5)*20L);
        tps.put(p.getUniqueId(), task);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!tps.containsKey(e.getPlayer().getUniqueId())) return;
        if (e.getFrom().distance(e.getTo())>0) {
            tps.get(e.getPlayer().getUniqueId()).cancel();
            tps.remove(e.getPlayer().getUniqueId());
        }
    }

    private void openGUI(Player viewer, UUID owner, boolean viewOnly) {
        Inventory inv = Bukkit.createInventory(null, 27,
                viewOnly ? Bukkit.getOfflinePlayer(owner).getName()+"'s Homes" : "Homes");

        for (int i=1;i<=MAX_HOMES;i++) {
            ItemStack bed = new ItemStack(Material.RED_BED);
            ItemMeta m = bed.getItemMeta();
            m.setDisplayName(ChatColor.GREEN+"Home "+i);
            List<String> lore = new ArrayList<>();

            boolean hasHome = homes.contains(owner+".home"+i);
            boolean hasPerm = i<=2 || viewer.hasPermission("dbadvancedhome.homes."+i) || viewOnly;

            if (!hasPerm) {
                bed.setType(Material.RED_BED);
                lore.add(ChatColor.RED+"You don't have permission");
            } else if (!hasHome) {
                bed.setType(Material.GRAY_BED);
                lore.add(ChatColor.GRAY+getConfig().getString("messages.click-set"));
            } else {
                bed.setType(Material.GREEN_BED);
                lore.add(ChatColor.GREEN+getConfig().getString("messages.click-teleport"));
            }
            m.setLore(lore);
            bed.setItemMeta(m);
            inv.setItem(i-1, bed);
        }
        viewer.openInventory(inv);
        play(viewer,"gui.open-sound");
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!e.getView().getTitle().contains("Homes")) return;
        e.setCancelled(true);

        ItemStack it = e.getCurrentItem();
        if (it==null) return;

        int slot = e.getSlot()+1;
        UUID owner = p.getUniqueId();
        boolean viewOnly = e.getView().getTitle().contains("'s Homes");

        if (viewOnly) {
            Location loc = homes.getLocation(owner+".home"+slot);
            if (loc!=null) startTeleport(p, loc);
            return;
        }

        if (!homes.contains(owner+".home"+slot)) {
            homes.set(owner+".home"+slot, p.getLocation());
            saveHomes();
            openGUI(p, owner, false);
        } else {
            startTeleport(p, homes.getLocation(owner+".home"+slot));
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getPlayer() instanceof Player p && e.getView().getTitle().contains("Homes"))
            play(p,"gui.close-sound");
    }
}
