
package me.db.dbadvancedhome;

import me.db.dbadvancedhome.command.DBHomeCommand;
import me.db.dbadvancedhome.gui.*;
import me.db.dbadvancedhome.home.HomeManager;
import me.db.dbadvancedhome.teleport.TeleportManager;
import me.db.dbadvancedhome.util.Msg;
import org.bukkit.plugin.java.JavaPlugin;

public class DBAdvancedHome extends JavaPlugin {

    private static DBAdvancedHome instance;
    private HomeManager homes;
    private TeleportManager tp;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        Msg.init(this);
        homes = new HomeManager(this);
        tp = new TeleportManager(this);

        getCommand("homes").setExecutor((s,c,l,a)->{
            if(s instanceof org.bukkit.entity.Player p){
                HomesGUI.open(p, p, false);
            }
            return true;
        });

        getCommand("dbhome").setExecutor(new DBHomeCommand(this));

        getServer().getPluginManager().registerEvents(new HomesGUI(this), this);
        getServer().getPluginManager().registerEvents(new ConfirmGUI(this), this);
        getServer().getPluginManager().registerEvents(tp, this);
    }

    public static DBAdvancedHome get(){ return instance; }
    public HomeManager homes(){ return homes; }
    public TeleportManager tp(){ return tp; }
}
