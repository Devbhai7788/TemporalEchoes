
package me.db.dbadvancedhome.teleport;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.util.Msg;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class TeleportManager implements Listener {

    private final DBAdvancedHome p;
    private final Map<UUID, Location> pending = new HashMap<>();

    public TeleportManager(DBAdvancedHome p){
        this.p = p;
    }

    public void startTeleport(Player pl, Location target){
        int delay = p.getConfig().getInt("teleport.delay");
        Msg.send(pl, "teleport-start");

        pending.put(pl.getUniqueId(), pl.getLocation());

        new BukkitRunnable(){
            @Override
            public void run(){
                if(!pending.containsKey(pl.getUniqueId())) return;

                pending.remove(pl.getUniqueId());
                pl.teleport(target);
                pl.playSound(pl.getLocation(),
                    Sound.valueOf(p.getConfig().getString("sounds.teleport-success")),1,1);
                Msg.title(pl);
            }
        }.runTaskLater(p, delay * 20L);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e){
        if(!p.getConfig().getBoolean("teleport.cancel-on-move")) return;
        if(!pending.containsKey(e.getPlayer().getUniqueId())) return;

        if(e.getFrom().distanceSquared(e.getTo()) > 0){
            pending.remove(e.getPlayer().getUniqueId());
            Msg.send(e.getPlayer(), "teleport-cancelled");
        }
    }
}
