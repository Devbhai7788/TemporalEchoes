
package me.db.dbadvancedhome.home;

import org.bukkit.*;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class HomeManager {
    private final File dir;

    public HomeManager(org.bukkit.plugin.Plugin p){
        dir = new File(p.getDataFolder(),"homes");
        if(!dir.exists()) dir.mkdirs();
    }

    private File f(UUID u){ return new File(dir,u+".yml"); }

    public boolean has(UUID u,int i){
        return f(u).exists() && YamlConfiguration.loadConfiguration(f(u)).contains("h."+i);
    }

    public void set(UUID u,int i,Location l){
        var y = YamlConfiguration.loadConfiguration(f(u));
        y.set("h."+i+".w",l.getWorld().getName());
        y.set("h."+i+".x",l.getX());
        y.set("h."+i+".y",l.getY());
        y.set("h."+i+".z",l.getZ());
        try{y.save(f(u));}catch(IOException ignored){}
    }

    public void unset(UUID u,int i){
        var y = YamlConfiguration.loadConfiguration(f(u));
        y.set("h."+i,null);
        try{y.save(f(u));}catch(IOException ignored){}
    }

    public Location get(UUID u,int i){
        if(!has(u,i)) return null;
        var y = YamlConfiguration.loadConfiguration(f(u));
        return new Location(
            Bukkit.getWorld(y.getString("h."+i+".w")),
            y.getDouble("h."+i+".x"),
            y.getDouble("h."+i+".y"),
            y.getDouble("h."+i+".z")
        );
    }
}
