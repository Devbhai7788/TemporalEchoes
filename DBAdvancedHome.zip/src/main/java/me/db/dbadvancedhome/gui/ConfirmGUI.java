
package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.util.Msg;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.*;

public class ConfirmGUI implements Listener {

    private final DBAdvancedHome p;
    public ConfirmGUI(DBAdvancedHome p){ this.p = p; }

    public static void open(Player pl, int id){
        Inventory inv = Bukkit.createInventory(null, 27, "Confirm:"+id);
        inv.setItem(11, new ItemStack(Material.LIME_DYE));
        inv.setItem(15, new ItemStack(Material.BARRIER));
        pl.openInventory(inv);
    }

    @EventHandler
    public void click(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player pl)) return;
        if(!e.getView().getTitle().startsWith("Confirm")) return;

        e.setCancelled(true);
        int id = Integer.parseInt(e.getView().getTitle().split(":")[1]);

        if(e.getSlot() == 11){
            p.homes().unset(pl.getUniqueId(), id);
            Msg.send(pl, "home-unset");
            HomesGUI.open(pl, pl, false);
        }else if(e.getSlot() == 15){
            HomesGUI.open(pl, pl, false);
        }
    }
}
