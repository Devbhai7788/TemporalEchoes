
package me.db.dbadvancedhome.gui;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.util.Msg;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.*;

public class HomesGUI implements Listener {

    private final DBAdvancedHome p;
    public HomesGUI(DBAdvancedHome p){ this.p = p; }

    public static void open(Player viewer, Player target, boolean admin){
        Inventory inv = Bukkit.createInventory(null, 27,
            Msg.color(DBAdvancedHome.get().getConfig()
            .getString(admin ? "gui.admin-title" : "gui.title")
            .replace("%player%", target.getName())));

        for(int i=1;i<=12;i++){
            boolean perm = admin || i<=2 || viewer.hasPermission("dbadvancedhome.homes."+i);
            boolean set = DBAdvancedHome.get().homes().has(target.getUniqueId(), i);

            Material mat = !perm ? Material.RED_BED : set ? Material.GREEN_BED : Material.GRAY_BED;
            ItemStack bed = new ItemStack(mat);
            ItemMeta bm = bed.getItemMeta();
            bm.setDisplayName(Msg.color(DBAdvancedHome.get().getConfig()
                .getString("gui.bed-name").replace("%id%", String.valueOf(i))));
            bm.setLore(DBAdvancedHome.get().getConfig()
                .getStringList(set ? "gui.lore-teleport" : "gui.lore-set"));
            bed.setItemMeta(bm);
            inv.setItem(i-1, bed);

            ItemStack dye = new ItemStack(Material.RED_DYE);
            ItemMeta dm = dye.getItemMeta();
            dm.setDisplayName(Msg.color("&cDelete"));
            dye.setItemMeta(dm);
            inv.setItem(i-1+9, dye);
        }

        viewer.openInventory(inv);
        viewer.playSound(viewer.getLocation(),
            Sound.valueOf(DBAdvancedHome.get().getConfig().getString("sounds.gui-open")),1,1);
    }

    @EventHandler
    public void click(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player pl)) return;
        if(!e.getView().getTitle().contains("Homes")) return;

        e.setCancelled(true);
        int slot = e.getSlot();
        int id = slot % 9 + 1;

        if(slot < 9){
            if(p.homes().has(pl.getUniqueId(), id)){
                p.tp().startTeleport(pl, p.homes().get(pl.getUniqueId(), id));
            }else{
                p.homes().set(pl.getUniqueId(), id, pl.getLocation());
                Msg.send(pl, "home-set");
                open(pl, pl, false);
            }
        }else if(slot >= 9 && slot < 21){
            ConfirmGUI.open(pl, id);
        }
    }
}
