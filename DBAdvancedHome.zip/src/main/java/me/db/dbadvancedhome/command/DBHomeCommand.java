
package me.db.dbadvancedhome.command;

import me.db.dbadvancedhome.DBAdvancedHome;
import me.db.dbadvancedhome.gui.HomesGUI;
import me.db.dbadvancedhome.util.Msg;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class DBHomeCommand implements CommandExecutor {

    private final DBAdvancedHome p;
    public DBHomeCommand(DBAdvancedHome p){ this.p = p; }

    public boolean onCommand(CommandSender s, Command c, String l, String[] a){
        if(!(s instanceof Player pl)) return true;
        if(!pl.hasPermission("dbadvancedhome.admin")) return true;

        if(a.length == 2 && a[0].equalsIgnoreCase("view")){
            OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
            Msg.send(pl, "admin-view".replace("%player%", t.getName()));
            HomesGUI.open(pl, pl, true);
        }
        return true;
    }
}
