
package me.db.dbadvancedhome.util;

import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import me.db.dbadvancedhome.DBAdvancedHome;

public class Msg {
    private static FileConfiguration c;

    public static void init(DBAdvancedHome p){
        c = p.getConfig();
    }

    public static String color(String s){
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public static void send(Player p, String path){
        p.sendMessage(color(c.getString("prefix")+c.getString("messages."+path)));
    }

    public static void title(Player p){
        p.sendTitle(
            color(c.getString("titles.success.title")),
            color(c.getString("titles.success.subtitle")),
            c.getInt("titles.success.fadein"),
            c.getInt("titles.success.stay"),
            c.getInt("titles.success.fadeout")
        );
    }
}
